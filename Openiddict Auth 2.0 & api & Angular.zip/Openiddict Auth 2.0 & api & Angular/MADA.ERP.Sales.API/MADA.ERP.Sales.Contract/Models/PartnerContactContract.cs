﻿namespace MADA.ERP.Sales.Contract.Models
{
    using MADA.ERP.Sales.Common;

    public class PartnerContactContract
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string SLName { get; set; }
        public ContactType ContactType { get; set; }
        public int? TitleId { get; set; }
        public int PartnerId { get; set; }
        public string Designation { get; set; }
        public string Notes { get; set; }
        public string Street { get; set; }
        public string Street2 { get; set; }
        public string Zip { get; set; }
        public int? CityId { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Mobile { get; set; }
        public string Fax { get; set; }
        public string Website { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public bool Active { get; set; }
    }
}
