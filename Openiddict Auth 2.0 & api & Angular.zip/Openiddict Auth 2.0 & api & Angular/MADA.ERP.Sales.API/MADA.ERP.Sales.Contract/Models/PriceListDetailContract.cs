﻿
namespace MADA.ERP.Sales.Contract.Models
{
    public class PriceListDetailContract
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int UnitId { get; set; }
        public float UnitPrice { get; set; }
        public float SpecialPrice { get; set; }
        public float MinQty { get; set; }
    }
}
