﻿
namespace MADA.ERP.Sales.Contract.Models
{
    public class PartnerSearchByTypeContract : SearchContract
    {
        public bool? IsCompany { get; set; }
        public bool? IsVendor { get; set; }
        public bool? IsCustomer { get; set; }
        public bool? IsEmployee { get; set; }
    }
}
