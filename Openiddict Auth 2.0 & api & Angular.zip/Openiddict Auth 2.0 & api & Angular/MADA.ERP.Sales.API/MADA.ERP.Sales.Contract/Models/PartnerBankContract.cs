﻿namespace MADA.ERP.Sales.Contract.Models
{
    public class PartnerBankContract
    {
        public int Id { get; set; }
        public string AccountNumber { get; set; }
        public int PartnerId { get; set; }
        public int? BankId { get; set; }
        public int? CurrencyId { get; set; }
        public int? CompanyId { get; set; }
        public bool Active { get; set; }
    }
}
