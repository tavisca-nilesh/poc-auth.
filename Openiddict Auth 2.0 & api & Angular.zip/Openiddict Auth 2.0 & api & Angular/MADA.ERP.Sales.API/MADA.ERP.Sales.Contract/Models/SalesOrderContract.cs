﻿
namespace MADA.ERP.Sales.Contract.Models
{
    using MADA.ERP.Sales.Common;
    using System;
    using System.Collections.Generic;

    public class SalesOrderContract
    {
        public int Id { get; set; }
        public string CustomerReference { get; set; }
        public SalesOrderStatus Status { get; set; }
        public DateTime? QuotationDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public DateTime? ConfirmationDate { get; set; }
        public int? SalesPersonId { get; set; }
        public int? PartnerId { get; set; }
        public int? InvoiceAddressId { get; set; }
        public int? DeliveryAddressId { get; set; }
        public int? PricelistId { get; set; }
        public int? CurrencyId { get; set; }
        public double? ExchangeRate { get; set; }
        public double? Total { get; set; }
        public double? DiscountAmt { get; set; }
        public string TermsAndConditions { get; set; }
        public int? PaymentTermsId { get; set; }
        public int? LocationId { get; set; }
        public int? ShippingPolicyId { get; set; }
        public int? VersionId { get; set; }
        public bool IsVersion { get; set; }
        public List<SalesOrderLineContract> SalesOrderLine { get; set; }

    }
}
