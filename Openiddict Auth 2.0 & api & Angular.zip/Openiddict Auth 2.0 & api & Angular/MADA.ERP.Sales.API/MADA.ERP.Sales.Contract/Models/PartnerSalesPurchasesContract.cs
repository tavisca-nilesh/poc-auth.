﻿namespace MADA.ERP.Sales.Contract.Models
{
    public class PartnerSalesPurchasesContract
    {
        public bool IsCustomer { get; set; }
        public bool IsVendor { get; set; }
        public int? SalesPersonId { get; set; }
        public string InternalRef { get; set; }
        public int? PriceListId { get; set; }
        public string Barcode { get; set; }
        public int? SupplierCurrencyId { get; set; }
        public bool IsPreferEReceipt { get; set; }
    }
}