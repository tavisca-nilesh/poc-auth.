﻿

namespace MADA.ERP.Sales.Contract.Models
{
    using System;

    public class UnitPriceContract
    {
        public int PriceListId { get; set; }
        public int ProductId { get; set; }
        public int UnitId { get; set; }
        public DateTime TransactionDate { get; set; }
    }
}
