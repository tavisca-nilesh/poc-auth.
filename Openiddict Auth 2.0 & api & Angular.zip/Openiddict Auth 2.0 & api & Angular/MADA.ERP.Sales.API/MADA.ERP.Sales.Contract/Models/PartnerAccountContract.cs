﻿namespace MADA.ERP.Sales.Contract.Models
{
    public class PartnerAccountContract
    {
        public int Id { get; set; }
        public int PartnerId { get; set; }
        public int? CustomerTermsId { get; set; }
        public int? VendorTermsId { get; set; }
        public int? DegreeOfTrustId { get; set; }
        public int? AccountRecId { get; set; }
        public int? AccountPayId { get; set; }
        public bool Active { get; set; }
    }
}
