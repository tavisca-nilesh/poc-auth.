﻿namespace MADA.ERP.Sales.Contract.Models
{
    using MADA.ERP.Sales.Common;
    using System;

    public class PriceListContract
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public PriceListType TypeOfPriceList { get; set; }
        public int? LocationId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool IsPromotional { get; set; }
        public bool IsUpdateTransValue { get; set; }
        public bool IsUpdatePost { get; set; }
        public bool IsPublic { get; set; }
        public bool Active { get; set; }
    }
}
