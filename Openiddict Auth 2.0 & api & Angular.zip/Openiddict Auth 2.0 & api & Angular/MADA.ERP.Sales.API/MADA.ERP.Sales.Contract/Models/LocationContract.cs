﻿namespace MADA.ERP.Sales.Contract.Models
{
    using MADA.ERP.Sales.Common;

    public class LocationContract
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string SLName { get; set; }
        public int? ParentWareHouseId { get; set; }
        public LocationType LocationType { get; set; }
        public bool IsScrap { get; set; }
        public bool IsReturn { get; set; }
        public string Barcode { get; set; }
        public int? OwnerId { get; set; }
        public bool Active { get; set; }
    }
}
