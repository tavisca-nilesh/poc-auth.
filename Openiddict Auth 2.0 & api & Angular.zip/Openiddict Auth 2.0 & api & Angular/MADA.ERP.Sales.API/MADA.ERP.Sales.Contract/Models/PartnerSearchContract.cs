﻿
namespace MADA.ERP.Sales.Contract.Models
{
    public class PartnerSearchContract : SearchContract
    {
        public bool? IsCompany { get; set; }
    }
}
