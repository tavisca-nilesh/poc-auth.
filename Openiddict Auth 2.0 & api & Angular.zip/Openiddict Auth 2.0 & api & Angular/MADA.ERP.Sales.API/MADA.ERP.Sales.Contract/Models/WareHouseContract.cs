﻿
namespace MADA.ERP.Sales.Contract.Models
{
    public class WareHouseContract
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string SLName { get; set; }
        public bool Active { get; set; }
    }
}
