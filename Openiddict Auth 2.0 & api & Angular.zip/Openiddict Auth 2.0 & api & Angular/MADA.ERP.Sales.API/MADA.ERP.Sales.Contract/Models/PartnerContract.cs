﻿namespace MADA.ERP.Sales.Contract.Models
{
    using MADA.ERP.Sales.Common;
    public class PartnerContract
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string SLName { get; set; }
        public string DisplayName { get; set; }
        public int? TitleId { get; set; }
        public int? CompanyId { get; set; }
        public int? LangId { get; set; }
        public int? TimezoneId { get; set; }
        public string TIN { get; set; }
        public string Website { get; set; }
        public double CreditLimit { get; set; }
        public bool Active { get; set; }
        public bool IsEmployee { get; set; }
        public string JobPosition { get; set; }
        public string Street { get; set; }
        public string Street2 { get; set; }
        public string Zip { get; set; }
        public int? CityId { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Mobile { get; set; }
        public bool IsCompany { get; set; }
        public PartnerPageType PartnerPageType { get; set; }
        public PartnerType PartnerType { get; set; }
    }

    public class PartnerIconContract
    {
        public int Id { get; set; }
        public byte[] Icon { get; set; }
    }
}
