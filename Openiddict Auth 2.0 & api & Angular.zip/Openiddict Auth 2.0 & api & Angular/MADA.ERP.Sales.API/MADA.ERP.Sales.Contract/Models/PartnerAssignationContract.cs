﻿
namespace MADA.ERP.Sales.Contract.Models
{
    public class PartnerAssignationContract
    {
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
    }
}
