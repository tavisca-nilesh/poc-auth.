namespace MADA.ERP.Sales.Contract.Models
{
    public class SampleContract
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
