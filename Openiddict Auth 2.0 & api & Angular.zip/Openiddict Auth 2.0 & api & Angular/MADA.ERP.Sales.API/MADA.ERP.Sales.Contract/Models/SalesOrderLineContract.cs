﻿
namespace MADA.ERP.Sales.Contract.Models
{
    public class SalesOrderLineContract
    {
		public int Id { get; set; }
		public int? ProductId { get; set; }
		public string Description { get; set; }
		public int SequenceNo { get; set; }
		public double Qty { get; set; }
		public double UnitPrice { get; set; }
		public double FreeQty { get; set; }
		public double Taxes { get; set; }
		public double DiscountPer { get; set; }
		public double DiscountAmount { get; set; }
		public double DiscountShareAmount { get; set; }
		public int? UnitId { get; set; }
	}
}
