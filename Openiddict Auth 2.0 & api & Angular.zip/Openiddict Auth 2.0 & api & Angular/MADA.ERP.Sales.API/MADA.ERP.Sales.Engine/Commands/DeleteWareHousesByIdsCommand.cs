﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public sealed class DeleteWarehousesByIdsCommand : ICommand<SuccessFailureDomain>
    {
        public List<int> Ids { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeleteWarehousesByIdsCommandHandler : ICommandHandler<DeleteWarehousesByIdsCommand, SuccessFailureDomain>
    {
        private readonly IWareHouseRepository _warehouseRepository;
        public DeleteWarehousesByIdsCommandHandler(IWareHouseRepository warehouseRepository)
        {
            _warehouseRepository = warehouseRepository;
        }

        public async Task<SuccessFailureDomain> Handle(DeleteWarehousesByIdsCommand command)
        {
            command.Ids.ThrowIfNullOrEmpty<int>("Empty list parameter", nameof(command.Ids));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _warehouseRepository.DeleteWarehousesByIdsAsync(command.Ids, command.UserId).ConfigureAwait(false);
        }
    }
}
