﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class UpdatePartnerAssignationCommand : ICommand<int>
    {
        public int PartnerId { get; set; }
        public PartnerAssignationContract PartnerAssignation { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class UpdatePartnerAssignationCommandHandler : ICommandHandler<UpdatePartnerAssignationCommand, int>
    {
        private readonly IPartnerRepository _partnerRepository;
        public UpdatePartnerAssignationCommandHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<int> Handle(UpdatePartnerAssignationCommand command)
        {
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerRepository.UpdatePartnerAssignationAsync(command.PartnerId, command.PartnerAssignation, command.UserId).ConfigureAwait(false);
        }
    }
}
