﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class DeletePartnerContactCommand : ICommand<bool>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeletePartnerContactCommandHandler : ICommandHandler<DeletePartnerContactCommand, bool>
    {
        private readonly IPartnerContactRepository _partnerContactRepository;
        public DeletePartnerContactCommandHandler(IPartnerContactRepository partnerContactRepository)
        {
            _partnerContactRepository = partnerContactRepository;
        }

        public async Task<bool> Handle(DeletePartnerContactCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid partner contact id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerContactRepository.DeletePartnerContactAsync(command.Id, command.UserId).ConfigureAwait(false);
        }
    }
}
