﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Threading.Tasks;

    public sealed class DeleteSalesOrderCommand : ICommand<bool>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeleteSalesOrderCommandHandler : ICommandHandler<DeleteSalesOrderCommand, bool>
    {
        private readonly ISalesOrderRepository _salesOrderRepository;
        public DeleteSalesOrderCommandHandler(ISalesOrderRepository salesOrderRepository)
        {
            _salesOrderRepository = salesOrderRepository;
        }

        public async Task<bool> Handle(DeleteSalesOrderCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid sales order id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _salesOrderRepository.DeleteSalesOrderAsync(command.Id, command.UserId).ConfigureAwait(false);
        }
    }
}
