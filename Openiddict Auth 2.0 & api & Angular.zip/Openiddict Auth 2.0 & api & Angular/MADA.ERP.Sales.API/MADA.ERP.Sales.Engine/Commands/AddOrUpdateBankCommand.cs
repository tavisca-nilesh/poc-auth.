﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class AddOrUpdateBankCommand : ICommand<int>
    {
        public BankContract Bank { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdateBankCommandHandler : ICommandHandler<AddOrUpdateBankCommand, int>
    {
        private readonly IBankRepository _bankRepository;
        public AddOrUpdateBankCommandHandler(IBankRepository bankRepository)
        {
            _bankRepository = bankRepository;
        }

        public async Task<int> Handle(AddOrUpdateBankCommand command)
        {
            command.Bank.Name.ThrowIfNullOrEmpty("Invalid bank name parameter", nameof(command.Bank.Name));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _bankRepository.AddOrUpdateBankAsync(command.Bank, command.UserId).ConfigureAwait(false);
        }
    }
}
