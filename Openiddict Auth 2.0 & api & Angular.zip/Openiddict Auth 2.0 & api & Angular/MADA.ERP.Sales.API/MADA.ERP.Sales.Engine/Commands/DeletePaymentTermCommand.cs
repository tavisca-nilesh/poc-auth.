﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class DeletePaymentTermCommand : ICommand<bool>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeletePaymentTermCommandHandler : ICommandHandler<DeletePaymentTermCommand, bool>
    {
        private readonly IPaymentTermRepository _paymentTermRepository;
        public DeletePaymentTermCommandHandler(IPaymentTermRepository paymentTermRepository)
        {
            _paymentTermRepository = paymentTermRepository;
        }

        public async Task<bool> Handle(DeletePaymentTermCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid payment term id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _paymentTermRepository.DeletePaymentTermAsync(command.Id, command.UserId).ConfigureAwait(false);
        }
    }
}
