﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class AddOrUpdateWareHouseCommand : ICommand<int>
    {
        public WareHouseContract WareHouse { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdateWareHouseCommandHandler : ICommandHandler<AddOrUpdateWareHouseCommand, int>
    {
        private readonly IWareHouseRepository _wareHouseRepository;
        public AddOrUpdateWareHouseCommandHandler(IWareHouseRepository wareHouseRepository)
        {
            _wareHouseRepository = wareHouseRepository;
        }

        public async Task<int> Handle(AddOrUpdateWareHouseCommand command)
        {
            command.WareHouse.Name.ThrowIfNullOrEmpty("Invalid ware house name parameter", nameof(command.WareHouse.Name));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _wareHouseRepository.AddOrUpdateWareHouseAsync(command.WareHouse, command.UserId).ConfigureAwait(false);
        }
    }
}
