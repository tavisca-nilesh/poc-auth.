﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class DeletePartnerAccountCommand : ICommand<bool>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeletePartnerAccountCommandHandler : ICommandHandler<DeletePartnerAccountCommand, bool>
    {
        private readonly IPartnerAccountRepository _partnerAccountRepository;
        public DeletePartnerAccountCommandHandler(IPartnerAccountRepository partnerAccountRepository)
        {
            _partnerAccountRepository = partnerAccountRepository;
        }

        public async Task<bool> Handle(DeletePartnerAccountCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid partner Account id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerAccountRepository.DeletePartnerAccountAsync(command.Id, command.UserId).ConfigureAwait(false);
        }
    }
}
