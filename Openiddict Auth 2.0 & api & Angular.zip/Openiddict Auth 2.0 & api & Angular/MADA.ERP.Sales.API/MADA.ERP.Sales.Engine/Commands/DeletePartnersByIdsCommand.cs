﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public sealed class DeletePartnersByIdsCommand : ICommand<SuccessFailureDomain>
    {
        public List<int> Ids { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeletePartnersByIdsCommandHandler : ICommandHandler<DeletePartnersByIdsCommand, SuccessFailureDomain>
    {
        private readonly IPartnerRepository _partnerRepository;
        public DeletePartnersByIdsCommandHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<SuccessFailureDomain> Handle(DeletePartnersByIdsCommand command)
        {
            command.Ids.ThrowIfNullOrEmpty<int>("Empty list parameter", nameof(command.Ids));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerRepository.DeletePartnersByIdsAsync(command.Ids, command.UserId).ConfigureAwait(false);
        }
    }
}
