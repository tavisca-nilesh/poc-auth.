﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class AddOrUpdatePartnerBankCommand : ICommand<int>
    {
        public PartnerBankContract PartnerBank { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdatePartnerBankCommandHandler : ICommandHandler<AddOrUpdatePartnerBankCommand, int>
    {
        private readonly IPartnerBankRepository _partnerBankRepository;

        public AddOrUpdatePartnerBankCommandHandler(IPartnerBankRepository partnerBankRepository)
        {
            _partnerBankRepository = partnerBankRepository;
        }

        public async Task<int> Handle(AddOrUpdatePartnerBankCommand command)
        {
            command.PartnerBank.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid partner id parameter", nameof(command.PartnerBank.PartnerId));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerBankRepository.AddOrUpdatePartnerBankAsync(command.PartnerBank, command.UserId).ConfigureAwait(false);
        }
    }
}
