﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class AddOrUpdateLocationCommand : ICommand<int>
    {
        public LocationContract Location { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdateLocationCommandHandler : ICommandHandler<AddOrUpdateLocationCommand, int>
    {
        private readonly ILocationRepository _locationRepository;
        public AddOrUpdateLocationCommandHandler(ILocationRepository locationRepository)
        {
            _locationRepository = locationRepository;
        }

        public async Task<int> Handle(AddOrUpdateLocationCommand command)
        {
            command.Location.Name.ThrowIfNullOrEmpty("Invalid location name parameter", nameof(command.Location.Name));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _locationRepository.AddOrUpdateLocationAsync(command.Location, command.UserId).ConfigureAwait(false);
        }
    }
}
