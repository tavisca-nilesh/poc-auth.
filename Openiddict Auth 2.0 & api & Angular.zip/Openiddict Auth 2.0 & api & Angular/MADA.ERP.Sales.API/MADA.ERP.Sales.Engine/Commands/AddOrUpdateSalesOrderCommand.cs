﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using System;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class AddOrUpdateSalesOrderCommand : ICommand<int>
    {
        public SalesOrderContract SalesOrder { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdateSalesOrderCommandHandler : ICommandHandler<AddOrUpdateSalesOrderCommand, int>
    {
        private readonly ISalesOrderRepository _salesOrderRepository;
        public AddOrUpdateSalesOrderCommandHandler(ISalesOrderRepository salesOrderRepository)
        {
            _salesOrderRepository = salesOrderRepository;
        }

        public async Task<int> Handle(AddOrUpdateSalesOrderCommand command)
        {
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            if (Enum.IsDefined(typeof(SalesOrderStatus), command.SalesOrder.Status) == false) { throw new ValidationException("Invalid Sales order status", command.SalesOrder.Status.ToString()); }
            return await _salesOrderRepository.AddOrUpdateSalesOrderAsync(command.SalesOrder, command.UserId).ConfigureAwait(false);
        }
    }
}
