﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public sealed class DeleteBanksByIdsCommand : ICommand<SuccessFailureDomain>
    {
        public List<int> Ids { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeleteBanksByIdsCommandHandler : ICommandHandler<DeleteBanksByIdsCommand, SuccessFailureDomain>
    {
        private readonly IBankRepository _bankRepository;
        public DeleteBanksByIdsCommandHandler(IBankRepository bankRepository)
        {
            _bankRepository = bankRepository;
        }

        public async Task<SuccessFailureDomain> Handle(DeleteBanksByIdsCommand command)
        {
            command.Ids.ThrowIfNullOrEmpty<int>("Empty list parameter", nameof(command.Ids));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _bankRepository.DeleteBanksByIdsAsync(command.Ids, command.UserId).ConfigureAwait(false);
        }
    }
}
