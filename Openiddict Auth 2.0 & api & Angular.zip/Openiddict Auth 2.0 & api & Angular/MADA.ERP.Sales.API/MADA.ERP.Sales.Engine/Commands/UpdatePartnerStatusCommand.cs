﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class UpdatePartnerStatusCommand : ICommand<int>
    {
        public int Id { get; set; }
        public bool Status { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class UpdatePartnerStatusCommandHandler : ICommandHandler<UpdatePartnerStatusCommand, int>
    {
        private readonly IPartnerRepository _partnerRepository;
        public UpdatePartnerStatusCommandHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<int> Handle(UpdatePartnerStatusCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid partner id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerRepository.UpdatePartnerStatusAsync(command.Id, command.Status, command.UserId).ConfigureAwait(false);
        }
    }
}
