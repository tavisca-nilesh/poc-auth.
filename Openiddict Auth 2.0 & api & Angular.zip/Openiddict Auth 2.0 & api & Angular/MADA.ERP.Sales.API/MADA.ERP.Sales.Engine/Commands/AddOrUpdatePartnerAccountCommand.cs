﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class AddOrUpdatePartnerAccountCommand : ICommand<int>
    {
        public PartnerAccountContract PartnerAccount { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdatePartnerAccountCommandHandler : ICommandHandler<AddOrUpdatePartnerAccountCommand, int>
    {
        private readonly IPartnerAccountRepository _partnerAccountRepository;
        public AddOrUpdatePartnerAccountCommandHandler(IPartnerAccountRepository partnerAccountRepository)
        {
            _partnerAccountRepository = partnerAccountRepository;
        }

        public async Task<int> Handle(AddOrUpdatePartnerAccountCommand command)
        {
            command.PartnerAccount.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid partner id parameter", nameof(command.PartnerAccount.PartnerId));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerAccountRepository.AddOrUpdatePartnerAccountAsync(command.PartnerAccount, command.UserId).ConfigureAwait(false);
        }
    }
}
