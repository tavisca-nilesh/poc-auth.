﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Threading.Tasks;

    public sealed class GetPartnerAssignationCommand : ICommand<PartnerAssignationDomain>
    {
        public int PartnerId { get; set; }
    }
    public class GetPartnerAssignationCommandHandler : ICommandHandler<GetPartnerAssignationCommand, PartnerAssignationDomain>
    {
        private readonly IPartnerRepository _partnerRepository;
        public GetPartnerAssignationCommandHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<PartnerAssignationDomain> Handle(GetPartnerAssignationCommand command)
        {
            command.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid partner id parameter", nameof(command.PartnerId));
            return await _partnerRepository.GetPartnerAssignationAsync(command.PartnerId).ConfigureAwait(false);
        }
    }
}
