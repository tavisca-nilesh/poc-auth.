﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class UpdateSalesOrderStatusCommand : ICommand<int>
    {
        public int Id { get; set; }
        public SalesOrderStatus Status { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class UpdateSalesOrderStatusCommandHandler : ICommandHandler<UpdateSalesOrderStatusCommand, int>
    {
        private readonly ISalesOrderRepository _salesOrderRepository;
        public UpdateSalesOrderStatusCommandHandler(ISalesOrderRepository salesOrderRepository)
        {
            _salesOrderRepository = salesOrderRepository;
        }

        public async Task<int> Handle(UpdateSalesOrderStatusCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid Sales Order id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            if (Enum.IsDefined(typeof(SalesOrderStatus), command.Status) == false) { throw new ValidationException("Invalid Sales order status", command.Status.ToString()); }
            return await _salesOrderRepository.UpdateSalesOrderStatus(command.Id, command.Status, command.UserId).ConfigureAwait(false);
        }
    }
}
