﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class UpdatePartnerSalesPurchasesCommand : ICommand<int>
    {
        public PartnerSalesPurchasesContract PartnerSalesPurchases { get; set; }
        public int PartnerId { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdatePartnerSalesPurchasesCommandHandler : ICommandHandler<UpdatePartnerSalesPurchasesCommand, int>
    {
        private readonly IPartnerSalesPurchasesRepository _partnerSalesPurchasesRepository;
        public AddOrUpdatePartnerSalesPurchasesCommandHandler(IPartnerSalesPurchasesRepository partnerSalesPurchasesRepository)
        {
            _partnerSalesPurchasesRepository = partnerSalesPurchasesRepository;
        }

        public async Task<int> Handle(UpdatePartnerSalesPurchasesCommand command)
        {
            command.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid partner id parameter", nameof(command.PartnerId));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerSalesPurchasesRepository.UpdatePartnerSalesPurchasesAsync(command.PartnerSalesPurchases, command.PartnerId, command.UserId).ConfigureAwait(false);
        }
    }
}
