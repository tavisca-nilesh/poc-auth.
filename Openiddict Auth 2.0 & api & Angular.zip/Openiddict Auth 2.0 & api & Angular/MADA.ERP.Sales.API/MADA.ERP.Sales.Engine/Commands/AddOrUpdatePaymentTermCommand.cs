﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class AddOrUpdatePaymentTermCommand : ICommand<int>
    {
        public PaymentTermContract PaymentTerm { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdatePaymentTermCommandHandler : ICommandHandler<AddOrUpdatePaymentTermCommand, int>
    {
        private readonly IPaymentTermRepository _paymentTermRepository;
        public AddOrUpdatePaymentTermCommandHandler(IPaymentTermRepository paymentTermRepository)
        {
            _paymentTermRepository = paymentTermRepository;
        }

        public async Task<int> Handle(AddOrUpdatePaymentTermCommand command)
        {
            command.PaymentTerm.Name.ThrowIfNullOrEmpty("Invalid payment term name parameter", nameof(command.PaymentTerm.Name));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _paymentTermRepository.AddOrUpdatePaymentTermAsync(command.PaymentTerm, command.UserId).ConfigureAwait(false);
        }
    }
}
