﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class AddOrUpdatePartnerContactCommand : ICommand<int>
    {
        public PartnerContactContract PartnerContact { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdatePartnerContactCommandHandler : ICommandHandler<AddOrUpdatePartnerContactCommand, int>
    {
        private readonly IPartnerContactRepository _partnerContactRepository;
        public AddOrUpdatePartnerContactCommandHandler(IPartnerContactRepository partnerContactRepository)
        {
            _partnerContactRepository = partnerContactRepository;
        }

        public async Task<int> Handle(AddOrUpdatePartnerContactCommand command)
        {
            command.PartnerContact.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid partner id parameter", nameof(command.PartnerContact.PartnerId));
            command.PartnerContact.Name.ThrowIfNullOrEmpty("Invalid partner contact name parameter", nameof(command.PartnerContact.Name));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerContactRepository.AddOrUpdatePartnerContactAsync(command.PartnerContact, command.UserId).ConfigureAwait(false);
        }
    }
}
