﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class UpdatePartnerNoteCommand : ICommand<int>
    {
        public int PartnerId { get; set; }
        public string Note { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class UpdatePartnerNoteCommandHandler : ICommandHandler<UpdatePartnerNoteCommand, int>
    {
        private readonly IPartnerRepository _partnerRepository;
        public UpdatePartnerNoteCommandHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<int> Handle(UpdatePartnerNoteCommand command)
        {
            command.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid partner id parameter", nameof(command.PartnerId));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerRepository.UpdatePartnerNoteAsync(command.PartnerId, command.Note, command.UserId).ConfigureAwait(false);
        }
    }
}
