﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;    

    public sealed class AddOrUpdatePartnerCommand : ICommand<int>
    {
        public PartnerContract Partner { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdatePartnerCommandHandler : ICommandHandler<AddOrUpdatePartnerCommand, int>
    {
        private readonly IPartnerRepository _partnerRepository;
        public AddOrUpdatePartnerCommandHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<int> Handle(AddOrUpdatePartnerCommand command)
        {
            command.Partner.Name.ThrowIfNullOrEmpty("Invalid partner name parameter", nameof(command.Partner.Name));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerRepository.AddOrUpdatePartnerAsync(command.Partner, command.UserId).ConfigureAwait(false);
        }
    }
}
