﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Threading.Tasks;

    public sealed class DeleteBankCommand : ICommand<bool>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeleteBankCommandHandler : ICommandHandler<DeleteBankCommand, bool>
    {
        private readonly IBankRepository _bankRepository;
        public DeleteBankCommandHandler(IBankRepository bankRepository)
        {
            _bankRepository = bankRepository;
        }

        public async Task<bool> Handle(DeleteBankCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid ware house id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _bankRepository.DeleteBankAsync(command.Id, command.UserId).ConfigureAwait(false);
        }
    }
}
