﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public sealed class DeleteLocationsByIdsCommand : ICommand<SuccessFailureDomain>
    {
        public List<int> Ids { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeleteLocationsByIdsCommandHandler : ICommandHandler<DeleteLocationsByIdsCommand, SuccessFailureDomain>
    {
        private readonly ILocationRepository _locationRepository;
        public DeleteLocationsByIdsCommandHandler(ILocationRepository locationRepository)
        {
            _locationRepository = locationRepository;
        }

        public async Task<SuccessFailureDomain> Handle(DeleteLocationsByIdsCommand command)
        {
            command.Ids.ThrowIfNullOrEmpty<int>("Empty list parameter", nameof(command.Ids));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _locationRepository.DeleteLocationsByIdsAsync(command.Ids, command.UserId).ConfigureAwait(false);
        }
    }
}
