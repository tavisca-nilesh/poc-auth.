﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Threading.Tasks;

    public sealed class DeletePartnerCommand : ICommand<bool>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeletePartnerCommandHandler : ICommandHandler<DeletePartnerCommand, bool>
    {
        private readonly IPartnerRepository _partnerRepository;
        public DeletePartnerCommandHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<bool> Handle(DeletePartnerCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid partner id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerRepository.DeletePartnerAsync(command.Id, command.UserId).ConfigureAwait(false);
        }
    }
}
