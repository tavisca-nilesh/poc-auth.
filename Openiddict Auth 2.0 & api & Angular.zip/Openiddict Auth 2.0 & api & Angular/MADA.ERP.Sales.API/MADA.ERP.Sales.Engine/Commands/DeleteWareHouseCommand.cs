﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Threading.Tasks;

    public sealed class DeleteWareHouseCommand : ICommand<bool>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeleteWareHouseCommandHandler : ICommandHandler<DeleteWareHouseCommand, bool>
    {
        private readonly IWareHouseRepository _wareHouseRepository;
        public DeleteWareHouseCommandHandler(IWareHouseRepository wareHouseRepository)
        {
            _wareHouseRepository = wareHouseRepository;
        }

        public async Task<bool> Handle(DeleteWareHouseCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid ware house id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _wareHouseRepository.DeleteWareHouseAsync(command.Id, command.UserId).ConfigureAwait(false);
        }
    }
}
