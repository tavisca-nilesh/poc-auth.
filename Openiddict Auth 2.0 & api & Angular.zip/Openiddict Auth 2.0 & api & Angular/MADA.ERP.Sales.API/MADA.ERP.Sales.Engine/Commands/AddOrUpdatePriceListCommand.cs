﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class AddOrUpdatePriceListCommand : ICommand<int>
    {
        public PriceListContract PriceList { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdatePriceListCommandHandler : ICommandHandler<AddOrUpdatePriceListCommand, int>
    {
        private readonly IPriceListRepository _priceListRepository;
        public AddOrUpdatePriceListCommandHandler(IPriceListRepository priceListRepository)
        {
            _priceListRepository = priceListRepository;
        }

        public async Task<int> Handle(AddOrUpdatePriceListCommand command)
        {
            command.PriceList.Name.ThrowIfNullOrEmpty("Invalid price list name parameter", nameof(command.PriceList.Name));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            if (Enum.IsDefined(typeof(PriceListType), command.PriceList.TypeOfPriceList) == false) { throw new ValidationException("Invalid Price list type", command.PriceList.TypeOfPriceList.ToString()); }
            return await _priceListRepository.AddOrUpdatePriceListAsync(command.PriceList, command.UserId).ConfigureAwait(false);
        }
    }
}
