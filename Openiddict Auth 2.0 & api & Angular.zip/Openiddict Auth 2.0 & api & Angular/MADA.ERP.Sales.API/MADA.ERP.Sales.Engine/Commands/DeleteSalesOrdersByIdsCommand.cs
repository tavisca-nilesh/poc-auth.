﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public sealed class DeleteSalesOrdersByIdsCommand : ICommand<SuccessFailureDomain>
    {
        public List<int> Ids { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeleteSalesOrdersByIdsCommandHandler : ICommandHandler<DeleteSalesOrdersByIdsCommand, SuccessFailureDomain>
    {
        private readonly ISalesOrderRepository _salesOrderRepository;
        public DeleteSalesOrdersByIdsCommandHandler(ISalesOrderRepository salesOrderRepository)
        {
            _salesOrderRepository = salesOrderRepository;
        }

        public async Task<SuccessFailureDomain> Handle(DeleteSalesOrdersByIdsCommand command)
        {
            command.Ids.ThrowIfNullOrEmpty<int>("Empty list parameter", nameof(command.Ids));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _salesOrderRepository.DeleteSalesOrdersByIdsAsync(command.Ids, command.UserId).ConfigureAwait(false);
        }
    }
}
