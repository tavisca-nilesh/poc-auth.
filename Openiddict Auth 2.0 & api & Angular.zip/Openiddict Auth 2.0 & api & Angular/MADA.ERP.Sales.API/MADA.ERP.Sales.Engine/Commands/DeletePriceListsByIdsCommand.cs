﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public sealed class DeletePriceListsByIdsCommand : ICommand<SuccessFailureDomain>
    {
        public List<int> Ids { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeletePriceListsByIdsCommandHandler : ICommandHandler<DeletePriceListsByIdsCommand, SuccessFailureDomain>
    {
        private readonly IPriceListRepository _priceListRepository;
        public DeletePriceListsByIdsCommandHandler(IPriceListRepository priceListRepository)
        {
            _priceListRepository = priceListRepository;
        }

        public async Task<SuccessFailureDomain> Handle(DeletePriceListsByIdsCommand command)
        {
            command.Ids.ThrowIfNullOrEmpty<int>("Empty list parameter", nameof(command.Ids));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _priceListRepository.DeletePriceListsByIdsAsync(command.Ids, command.UserId).ConfigureAwait(false);
        }
    }
}
