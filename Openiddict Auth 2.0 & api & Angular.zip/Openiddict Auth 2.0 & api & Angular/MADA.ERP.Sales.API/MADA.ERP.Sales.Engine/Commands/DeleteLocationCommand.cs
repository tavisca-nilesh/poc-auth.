﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Threading.Tasks;

    public sealed class DeleteLocationCommand : ICommand<bool>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeleteLocationCommandHandler : ICommandHandler<DeleteLocationCommand, bool>
    {
        private readonly ILocationRepository _locationRepository;
        public DeleteLocationCommandHandler(ILocationRepository locationRepository)
        {
            _locationRepository = locationRepository;
        }

        public async Task<bool> Handle(DeleteLocationCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid location id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _locationRepository.DeleteLocationAsync(command.Id, command.UserId).ConfigureAwait(false);
        }
    }
}
