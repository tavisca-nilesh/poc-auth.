﻿
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Threading.Tasks;

    public sealed class DeletePriceListCommand : ICommand<bool>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeletePriceListCommandHandler : ICommandHandler<DeletePriceListCommand, bool>
    {
        private readonly IPriceListRepository _priceListRepository;
        public DeletePriceListCommandHandler(IPriceListRepository priceListRepository)
        {
            _priceListRepository = priceListRepository;
        }

        public async Task<bool> Handle(DeletePriceListCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid price list id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _priceListRepository.DeletePriceListAsync(command.Id, command.UserId).ConfigureAwait(false);
        }
    }
}
