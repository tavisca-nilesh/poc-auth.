﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class AddOrUpdatePartnerIconCommand : ICommand<int>
    {
        public PartnerIconContract PartnerIcon { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class AddOrUpdatePartnerIconCommandHandler : ICommandHandler<AddOrUpdatePartnerIconCommand, int>
    {
        private readonly IPartnerRepository _partnerRepository;
        public AddOrUpdatePartnerIconCommandHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<int> Handle(AddOrUpdatePartnerIconCommand command)
        {
            command.PartnerIcon.Id.ThrowIfNotPositiveNonZeroInt("Invalid partner id parameter", nameof(command.PartnerIcon.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerRepository.AddOrUpdatePartnerIconAsync(command.PartnerIcon, command.UserId).ConfigureAwait(false);
        }
    }
}
