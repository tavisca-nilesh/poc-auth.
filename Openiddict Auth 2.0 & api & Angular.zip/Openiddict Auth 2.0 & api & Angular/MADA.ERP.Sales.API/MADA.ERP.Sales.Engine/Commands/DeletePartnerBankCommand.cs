﻿namespace MADA.ERP.Sales.Engine.Commands
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class DeletePartnerBankCommand : ICommand<bool>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
    }

    [AuditLog]
    public sealed class DeletePartnerBankCommandHandler : ICommandHandler<DeletePartnerBankCommand, bool>
    {
        private readonly IPartnerBankRepository _partnerBankRepository;
        public DeletePartnerBankCommandHandler(IPartnerBankRepository partnerBankRepository)
        {
            _partnerBankRepository = partnerBankRepository;
        }

        public async Task<bool> Handle(DeletePartnerBankCommand command)
        {
            command.Id.ThrowIfNotPositiveNonZeroInt("Invalid partner bank id parameter", nameof(command.Id));
            command.UserId.ThrowIfNotPositiveNonZeroInt("Invalid user id parameter", nameof(command.UserId));
            return await _partnerBankRepository.DeletePartnerBankAsync(command.Id, command.UserId).ConfigureAwait(false);
        }
    }
}
