
namespace MADA.ERP.Sales.Engine.Commands
{
    using MADA.ERP.Sales.Domain.Messages;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Threading.Tasks;

    
    public sealed class AddSampleCommand : ICommand<bool>
    {
        public string Name { get; set; }
        public AddSampleCommand(string name)
        {
            Name = name;
        }
    }

    [AuditLog]
    public sealed class AddSampleCommandHandler : ICommandHandler<AddSampleCommand, bool>
    {
        public async Task<bool> Handle(AddSampleCommand command)
        {

            if (command.Name == "string")
            {
                //command.Name.ThrowInvalidInputException(nameof(command.Name));
            }

            // convert command to domain
            var sampleMessage = new SampleMessage
            {
                Name = command.Name
            };

            return true;
        }
    }
}
