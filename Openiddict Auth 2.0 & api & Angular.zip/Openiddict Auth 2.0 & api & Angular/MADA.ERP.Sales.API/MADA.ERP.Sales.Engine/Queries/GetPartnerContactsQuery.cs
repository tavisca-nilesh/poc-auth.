﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerContactsQuery : IQuery<List<PartnerContactDomain>>
    {
        public int PartnerId { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerContactsQueryHandler : IQueryHandler<GetPartnerContactsQuery, List<PartnerContactDomain>>
    {
        private readonly IPartnerContactRepository _partnerContactRepository;
        public GetPartnerContactsQueryHandler(IPartnerContactRepository partnerContactRepository)
        {
            _partnerContactRepository = partnerContactRepository;
        }

        public async Task<List<PartnerContactDomain>> Handle(GetPartnerContactsQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Id", nameof(query.PartnerId));
            return await _partnerContactRepository.GetPartnerContactsAsync(query.PartnerId).ConfigureAwait(false);
        }
    }
}
