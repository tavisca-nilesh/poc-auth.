﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerSalesPurchasesQuery : IQuery<PartnerSalesPurchasesDomain>
    {
        public int PartnerId { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerSalesPurchasesQueryHandler : IQueryHandler<GetPartnerSalesPurchasesQuery, PartnerSalesPurchasesDomain>
    {
        private readonly IPartnerSalesPurchasesRepository _partnerSalesPurchasesRepository;
        public GetPartnerSalesPurchasesQueryHandler(IPartnerSalesPurchasesRepository partnerSalesPurchasesRepository)
        {
            _partnerSalesPurchasesRepository = partnerSalesPurchasesRepository;
        }

        public async Task<PartnerSalesPurchasesDomain> Handle(GetPartnerSalesPurchasesQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Id", nameof(query.PartnerId));
            return await _partnerSalesPurchasesRepository.GetPartnerSalesPurchasesAsync(query.PartnerId).ConfigureAwait(false);
        }
    }
}
