﻿
namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public class GetPriceListsQuery : IQuery<PriceListDomainList>
    {
        public SearchContract SearchContract { get; set; }
    }

    [AuditLog]
    public sealed class GetPriceListsQueryHandler : IQueryHandler<GetPriceListsQuery, PriceListDomainList>
    {
        private readonly IPriceListRepository _priceListRepository;
        public GetPriceListsQueryHandler(IPriceListRepository priceListRepository)
        {
            _priceListRepository = priceListRepository;
        }

        public async Task<PriceListDomainList> Handle(GetPriceListsQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            var searchContract = query.SearchContract;
            searchContract.PageNumber.ThrowIfNotPositiveNonZeroInt("Invalid page number parameter", nameof(searchContract.PageNumber));
            searchContract.PageSize.ThrowIfNotPositiveNonZeroInt("Invalid page size parameter", nameof(searchContract.PageSize));
            return await _priceListRepository.GetPriceListsAsync(query.SearchContract).ConfigureAwait(false);
        }
    }
}
