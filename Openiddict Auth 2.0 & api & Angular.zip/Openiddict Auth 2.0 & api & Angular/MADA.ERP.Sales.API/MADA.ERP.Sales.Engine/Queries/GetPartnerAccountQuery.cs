﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerAccountQuery : IQuery<PartnerAccountDomain>
    {
        public int PartnerId { get; set; }
        public int PartnerAccountId { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerAccountQueryHandler : IQueryHandler<GetPartnerAccountQuery, PartnerAccountDomain>
    {
        private readonly IPartnerAccountRepository _partnerAccountRepository;
        public GetPartnerAccountQueryHandler(IPartnerAccountRepository partnerAccountRepository)
        {
            _partnerAccountRepository = partnerAccountRepository;
        }

        public async Task<PartnerAccountDomain> Handle(GetPartnerAccountQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Id", nameof(query.PartnerId));
            query.PartnerAccountId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Account Id", nameof(query.PartnerAccountId));
            return await _partnerAccountRepository.GetPartnerAccountByIdAsync(query.PartnerId, query.PartnerAccountId).ConfigureAwait(false);
        }
    }
}
