﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerContactQuery : IQuery<PartnerContactDomain>
    {
        public int PartnerId { get; set; }
        public int PartnerContactId { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerContactQueryHandler : IQueryHandler<GetPartnerContactQuery, PartnerContactDomain>
    {
        private readonly IPartnerContactRepository _partnerContactRepository;
        public GetPartnerContactQueryHandler(IPartnerContactRepository partnerContactRepository)
        {
            _partnerContactRepository = partnerContactRepository;
        }

        public async Task<PartnerContactDomain> Handle(GetPartnerContactQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Id", nameof(query.PartnerId));
            query.PartnerContactId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Contact Id", nameof(query.PartnerContactId));
            return await _partnerContactRepository.GetPartnerContactByIdAsync(query.PartnerId, query.PartnerContactId).ConfigureAwait(false);
        }
    }
}
