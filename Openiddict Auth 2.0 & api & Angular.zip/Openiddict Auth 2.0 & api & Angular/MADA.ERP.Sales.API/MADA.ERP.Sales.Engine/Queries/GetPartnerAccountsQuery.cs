﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerAccountsQuery : IQuery<List<PartnerAccountDomain>>
    {
        public int PartnerId { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerAccountsQueryHandler : IQueryHandler<GetPartnerAccountsQuery, List<PartnerAccountDomain>>
    {
        private readonly IPartnerAccountRepository _partnerAccountRepository;

        public GetPartnerAccountsQueryHandler(IPartnerAccountRepository partnerAccountRepository)
        {
            _partnerAccountRepository = partnerAccountRepository;
        }

        public async Task<List<PartnerAccountDomain>> Handle(GetPartnerAccountsQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Id", nameof(query.PartnerId));
            return await _partnerAccountRepository.GetPartnerAccountsAsync(query.PartnerId).ConfigureAwait(false);
        }
    }
}
