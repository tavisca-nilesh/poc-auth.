﻿
namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public class GetBankQuery : IQuery<BankDomain>
    {
        public int BankId { get; set; }
    }

    [AuditLog]
    public sealed class GetBankQueryHandler : IQueryHandler<GetBankQuery, BankDomain>
    {
        private readonly IBankRepository _bankRepository;
        public GetBankQueryHandler(IBankRepository bankRepository)
        {
            _bankRepository = bankRepository;
        }

        public async Task<BankDomain> Handle(GetBankQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.BankId.ThrowIfNotPositiveNonZeroInt("Invalid Bank Id", nameof(query.BankId));
            return await _bankRepository.GetBankByIdAsync(query.BankId).ConfigureAwait(false);
        }
    }
}
