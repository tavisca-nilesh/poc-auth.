﻿
namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public class GetPaymentTermsQuery : IQuery<PaymentTermListDomain>
    {
        public SearchContract SearchContract { get; set; }
    }

    [AuditLog]
    public sealed class GetPaymentTermsQueryHandler : IQueryHandler<GetPaymentTermsQuery, PaymentTermListDomain>
    {
        private readonly IPaymentTermRepository _paymentTermRepository;
        public GetPaymentTermsQueryHandler(IPaymentTermRepository paymentTermRepository)
        {
            _paymentTermRepository = paymentTermRepository;
        }

        public async Task<PaymentTermListDomain> Handle(GetPaymentTermsQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            var searchContract = query.SearchContract;
            searchContract.PageNumber.ThrowIfNotPositiveNonZeroInt("Invalid page number parameter", nameof(searchContract.PageNumber));
            searchContract.PageSize.ThrowIfNotPositiveNonZeroInt("Invalid page size parameter", nameof(searchContract.PageSize));
            return await _paymentTermRepository.GetPaymentTermListAsync(query.SearchContract).ConfigureAwait(false);
        }
    }
}
