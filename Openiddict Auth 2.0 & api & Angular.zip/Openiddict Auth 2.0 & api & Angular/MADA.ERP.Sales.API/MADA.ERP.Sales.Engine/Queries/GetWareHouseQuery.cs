﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public class GetWareHouseQuery : IQuery<WareHouseDomain>
    {
        public int WareHouseId { get; set; }
    }

    [AuditLog]
    public sealed class GetWareHouseQueryHandler : IQueryHandler<GetWareHouseQuery, WareHouseDomain>
    {
        private readonly IWareHouseRepository _wareHouseRepository;
        public GetWareHouseQueryHandler(IWareHouseRepository wareHouseRepository)
        {
            _wareHouseRepository = wareHouseRepository;
        }

        public async Task<WareHouseDomain> Handle(GetWareHouseQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.WareHouseId.ThrowIfNotPositiveNonZeroInt("Invalid Ware House Id", nameof(query.WareHouseId));
            return await _wareHouseRepository.GetWareHouseByIdAsync(query.WareHouseId).ConfigureAwait(false);
        }
    }
}
