﻿
namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public class GetBanksQuery : IQuery<BankListDomain>
    {
        public SearchContract SearchContract { get; set; }
    }

    [AuditLog]
    public sealed class GetBanksQueryHandler : IQueryHandler<GetBanksQuery, BankListDomain>
    {
        private readonly IBankRepository _bankRepository;
        public GetBanksQueryHandler(IBankRepository bankRepository)
        {
            _bankRepository = bankRepository;
        }

        public async Task<BankListDomain> Handle(GetBanksQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            var searchContract = query.SearchContract;
            searchContract.PageNumber.ThrowIfNotPositiveNonZeroInt("Invalid page number parameter", nameof(searchContract.PageNumber));
            searchContract.PageSize.ThrowIfNotPositiveNonZeroInt("Invalid page size parameter", nameof(searchContract.PageSize));
            return await _bankRepository.GetBankListAsync(query.SearchContract).ConfigureAwait(false);
        }
    }
}
