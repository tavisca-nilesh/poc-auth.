﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerBanksQuery : IQuery<List<PartnerBankDomain>>
    {
        public int PartnerId { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerBanksQueryHandler : IQueryHandler<GetPartnerBanksQuery, List<PartnerBankDomain>>
    {
        private readonly IPartnerBankRepository _partnerBankRepository;

        public GetPartnerBanksQueryHandler(IPartnerBankRepository partnerBankRepository)
        {
            _partnerBankRepository = partnerBankRepository;
        }

        public async Task<List<PartnerBankDomain>> Handle(GetPartnerBanksQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Id", nameof(query.PartnerId));
            return await _partnerBankRepository.GetPartnerBanksAsync(query.PartnerId).ConfigureAwait(false);
        }
    }
}
