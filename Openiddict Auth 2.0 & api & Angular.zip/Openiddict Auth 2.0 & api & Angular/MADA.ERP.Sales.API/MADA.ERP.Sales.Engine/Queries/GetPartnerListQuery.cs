﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerListQuery : IQuery<PartnerListDomain>
    {
        public PartnerSearchContract SearchContract { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerListQueryHandler : IQueryHandler<GetPartnerListQuery, PartnerListDomain>
    {
        private readonly IPartnerRepository _partnerRepository;
        public GetPartnerListQueryHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<PartnerListDomain> Handle(GetPartnerListQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            var searchContract = query.SearchContract;
            searchContract.PageNumber.ThrowIfNotPositiveNonZeroInt("Invalid page number parameter", nameof(searchContract.PageNumber));
            searchContract.PageSize.ThrowIfNotPositiveNonZeroInt("Invalid page size parameter", nameof(searchContract.PageSize));
            return await _partnerRepository.GetPartnerListAsync(query.SearchContract).ConfigureAwait(false);
        }
    }
}
