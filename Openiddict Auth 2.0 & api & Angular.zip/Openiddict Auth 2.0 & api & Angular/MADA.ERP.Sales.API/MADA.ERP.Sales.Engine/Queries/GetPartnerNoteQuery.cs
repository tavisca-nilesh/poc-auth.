﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerNoteQuery : IQuery<PartnerNoteDomain>
    {
        public int PartnerId { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerNoteQueryHandler : IQueryHandler<GetPartnerNoteQuery, PartnerNoteDomain>
    {
        private readonly IPartnerRepository _partnerRepository;
        public GetPartnerNoteQueryHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<PartnerNoteDomain> Handle(GetPartnerNoteQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Id", nameof(query.PartnerId));
            return await _partnerRepository.GetPartnerNoteAsync(query.PartnerId).ConfigureAwait(false);
        }
    }
}
