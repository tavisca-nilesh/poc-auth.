﻿
namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetUnitPriceQuery : IQuery<UnitPriceDomain>
    {
        public UnitPriceContract UnitPriceContract { get; set; }
    }

    [AuditLog]
    public sealed class GetUnitPriceQueryHandler : IQueryHandler<GetUnitPriceQuery, UnitPriceDomain>
    {
        private readonly ISalesOrderRepository _salesOrderRepository;
        public GetUnitPriceQueryHandler(ISalesOrderRepository salesOrderRepository)
        {
            _salesOrderRepository = salesOrderRepository;
        }

        public async Task<UnitPriceDomain> Handle(GetUnitPriceQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.UnitPriceContract.PriceListId.ThrowIfNotPositiveNonZeroInt("Invalid Price List Id", nameof(query.UnitPriceContract.PriceListId));
            query.UnitPriceContract.ProductId.ThrowIfNotPositiveNonZeroInt("Invalid Product Id", nameof(query.UnitPriceContract.ProductId));
            query.UnitPriceContract.UnitId.ThrowIfNotPositiveNonZeroInt("Invalid Unit Id", nameof(query.UnitPriceContract.UnitId));
            return await _salesOrderRepository.GetUnitPrice(query.UnitPriceContract).ConfigureAwait(false);
        }
    }
}
