﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerQuery : IQuery<PartnerFullDomain>
    {
        public int PartnerId { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerQueryHandler : IQueryHandler<GetPartnerQuery, PartnerFullDomain>
    {
        private readonly IPartnerRepository _partnerRepository;
        public GetPartnerQueryHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<PartnerFullDomain> Handle(GetPartnerQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Id", nameof(query.PartnerId));
            return await _partnerRepository.GetPartnerByIdAsync(query.PartnerId).ConfigureAwait(false);
        }
    }
}
