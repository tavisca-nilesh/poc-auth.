﻿
namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetSalesOrderQuery : IQuery<SalesOrderDomain>
    {
        public int SalesOrderId { get; set; }
    }

    [AuditLog]
    public sealed class GetSalesOrderQueryHandler : IQueryHandler<GetSalesOrderQuery, SalesOrderDomain>
    {
        private readonly ISalesOrderRepository _salesOrderRepository;
        public GetSalesOrderQueryHandler(ISalesOrderRepository salesOrderRepository)
        {
            _salesOrderRepository = salesOrderRepository;
        }

        public async Task<SalesOrderDomain> Handle(GetSalesOrderQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.SalesOrderId.ThrowIfNotPositiveNonZeroInt("Invalid sales order Id", nameof(query.SalesOrderId));
            return await _salesOrderRepository.GetSalesOrderByIdAsync(query.SalesOrderId).ConfigureAwait(false);
        }
    }
}
