﻿
namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public class GetWareHouseListQuery : IQuery<WareHouseListDomain>
    {
        public SearchContract SearchContract { get; set; }
    }

    [AuditLog]
    public sealed class GetWareHouseListQueryHandler : IQueryHandler<GetWareHouseListQuery, WareHouseListDomain>
    {
        private readonly IWareHouseRepository _wareHouseRepository;
        public GetWareHouseListQueryHandler(IWareHouseRepository wareHouseRepository)
        {
            _wareHouseRepository = wareHouseRepository;
        }

        public async Task<WareHouseListDomain> Handle(GetWareHouseListQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            var searchContract = query.SearchContract;
            searchContract.PageNumber.ThrowIfNotPositiveNonZeroInt("Invalid page number parameter", nameof(searchContract.PageNumber));
            searchContract.PageSize.ThrowIfNotPositiveNonZeroInt("Invalid page size parameter", nameof(searchContract.PageSize));
            return await _wareHouseRepository.GetWareHouseListAsync(query.SearchContract).ConfigureAwait(false);
        }
    }
}
