﻿
namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public class GetLocationQuery : IQuery<LocationDomain>
    {
        public int LocationId { get; set; }
    }

    [AuditLog]
    public sealed class GetLocationQueryHandler : IQueryHandler<GetLocationQuery, LocationDomain>
    {
        private readonly ILocationRepository _locationRepository;
        public GetLocationQueryHandler(ILocationRepository locationRepository)
        {
            _locationRepository = locationRepository;
        }

        public async Task<LocationDomain> Handle(GetLocationQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.LocationId.ThrowIfNotPositiveNonZeroInt("Invalid Location Id", nameof(query.LocationId));
            return await _locationRepository.GetLocationByIdAsync(query.LocationId).ConfigureAwait(false);
        }
    }
}