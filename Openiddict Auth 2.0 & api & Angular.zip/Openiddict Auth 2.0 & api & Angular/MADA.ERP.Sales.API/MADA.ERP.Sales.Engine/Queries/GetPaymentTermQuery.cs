﻿
namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public class GetPaymentTermQuery : IQuery<PaymentTermDomain>
    {
        public int PaymentTermId { get; set; }
    }

    [AuditLog]
    public sealed class GetPaymentTermQueryHandler : IQueryHandler<GetPaymentTermQuery, PaymentTermDomain>
    {
        private readonly IPaymentTermRepository _paymentTermRepository;
        public GetPaymentTermQueryHandler(IPaymentTermRepository paymentTermRepository)
        {
            _paymentTermRepository = paymentTermRepository;
        }

        public async Task<PaymentTermDomain> Handle(GetPaymentTermQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PaymentTermId.ThrowIfNotPositiveNonZeroInt("Invalid Payment Term Id", nameof(query.PaymentTermId));
            return await _paymentTermRepository.GetPaymentTermByIdAsync(query.PaymentTermId).ConfigureAwait(false);
        }
    }
}
