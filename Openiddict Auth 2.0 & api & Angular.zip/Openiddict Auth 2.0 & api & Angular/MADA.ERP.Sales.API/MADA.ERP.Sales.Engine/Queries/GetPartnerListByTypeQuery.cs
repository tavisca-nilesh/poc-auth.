﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerListByTypeQuery : IQuery<PartnerListDomain>
    {
        public PartnerSearchType PartnerSearchType { get; set; }
        public PartnerSearchContract SearchContract { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerListByTypeQueryHandler : IQueryHandler<GetPartnerListByTypeQuery, PartnerListDomain>
    {
        private readonly IPartnerRepository _partnerRepository;
        public GetPartnerListByTypeQueryHandler(IPartnerRepository partnerRepository)
        {
            _partnerRepository = partnerRepository;
        }

        public async Task<PartnerListDomain> Handle(GetPartnerListByTypeQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PartnerSearchType.ThrowIfNull("Invalid PartnerSearchType Enum", nameof(PartnerSearchType));
            return await _partnerRepository.GetPartnerListByTypeAsync(query.PartnerSearchType, query.SearchContract).ConfigureAwait(false);
        }
    }
}
