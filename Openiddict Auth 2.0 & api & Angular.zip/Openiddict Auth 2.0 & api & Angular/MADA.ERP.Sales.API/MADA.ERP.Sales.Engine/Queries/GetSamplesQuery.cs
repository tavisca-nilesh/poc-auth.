
namespace MADA.ERP.Sales.Engine.Queries
{
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public sealed class GetSampleListQuery : IQuery<List<SampleContract>>
    {
        //public int? Id { get; }

        //public GetSampleListQuery(int? id)
        //{
        //    Id = id;
        //}
    }

    [AuditLog]
    public sealed class GetSampleListQueryHandler : IQueryHandler<GetSampleListQuery, List<SampleContract>>
    {
        private readonly IDataRepository _dataRepository;
        public GetSampleListQueryHandler(IDataRepository dataRepository)
        {
            _dataRepository = dataRepository;
        }

        public async Task<List<SampleContract>> Handle(GetSampleListQuery query)
        {
            return await _dataRepository.GetSampleListAsync().ConfigureAwait(false);
        }
    }
}
