﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPartnerBankQuery : IQuery<PartnerBankDomain>
    {
        public int PartnerId { get; set; }
        public int BankId { get; set; }
    }

    [AuditLog]
    public sealed class GetPartnerBankQueryHandler : IQueryHandler<GetPartnerBankQuery, PartnerBankDomain>
    {
        private readonly IPartnerBankRepository _partnerBankRepository;

        public GetPartnerBankQueryHandler(IPartnerBankRepository partnerBankRepository)
        {
            _partnerBankRepository = partnerBankRepository;
        }

        public async Task<PartnerBankDomain> Handle(GetPartnerBankQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PartnerId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Id", nameof(query.PartnerId));
            query.BankId.ThrowIfNotPositiveNonZeroInt("Invalid Partner Bank Id", nameof(query.BankId));
            return await _partnerBankRepository.GetPartnerBankByIdAsync(query.PartnerId, query.BankId).ConfigureAwait(false);
        }
    }
}
