﻿
namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public class GetSalesOrdersQuery : IQuery<SalesOrderListDomain>
    {
        public SalesOrderSearchContract SearchContract { get; set; }
    }

    [AuditLog]
    public sealed class GetSalesOrdersQueryHandler : IQueryHandler<GetSalesOrdersQuery, SalesOrderListDomain>
    {
        private readonly ISalesOrderRepository _salesOrderRepository;
        public GetSalesOrdersQueryHandler(ISalesOrderRepository salesOrderRepository)
        {
            _salesOrderRepository = salesOrderRepository;
        }

        public async Task<SalesOrderListDomain> Handle(GetSalesOrdersQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            var searchContract = query.SearchContract;
            searchContract.PageNumber.ThrowIfNotPositiveNonZeroInt("Invalid page number parameter", nameof(searchContract.PageNumber));
            searchContract.PageSize.ThrowIfNotPositiveNonZeroInt("Invalid page size parameter", nameof(searchContract.PageSize));
            return await _salesOrderRepository.GetSalesOrderListAsync(query.SearchContract).ConfigureAwait(false);
        }
    }
}
