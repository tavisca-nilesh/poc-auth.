﻿namespace MADA.ERP.Sales.Engine.Queries
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    using MADA.ERP.Sales.Engine.Utils;

    public sealed class GetPriceListQuery : IQuery<PriceListDomain>
    {
        public int PriceListId { get; set; }
    }

    [AuditLog]
    public sealed class GetPriceListQueryHandler : IQueryHandler<GetPriceListQuery, PriceListDomain>
    {
        private readonly IPriceListRepository _priceListRepository;
        public GetPriceListQueryHandler(IPriceListRepository priceListRepository)
        {
            _priceListRepository = priceListRepository;
        }

        public async Task<PriceListDomain> Handle(GetPriceListQuery query)
        {
            query.ThrowIfNull("Invalid query parameter", nameof(query));
            query.PriceListId.ThrowIfNotPositiveNonZeroInt("Invalid Price List Id", nameof(query.PriceListId));
            return await _priceListRepository.GetPriceListByIdAsync(query.PriceListId).ConfigureAwait(false);
        }
    }
}
