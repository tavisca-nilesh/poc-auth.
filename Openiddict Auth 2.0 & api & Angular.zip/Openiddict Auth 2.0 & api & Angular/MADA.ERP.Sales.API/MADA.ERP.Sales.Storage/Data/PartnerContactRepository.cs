﻿namespace MADA.ERP.Sales.Storage.Data
{
    using System.Collections.Generic;
    using System.Data;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;

    public class PartnerContactRepository : IPartnerContactRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public PartnerContactRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> AddOrUpdatePartnerContactAsync(PartnerContactContract partnerContact, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertPartnerContact;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                partnerContact.Id,
                partnerContact.Name,
                partnerContact.SLName,
                partnerContact.ContactType,
                partnerContact.TitleId,
                partnerContact.PartnerId,
                partnerContact.Designation,
                partnerContact.Notes,
                partnerContact.Street,
                partnerContact.Street2,
                partnerContact.Zip,
                partnerContact.CityId,
                partnerContact.Email,
                partnerContact.Phone,
                partnerContact.Mobile,
                partnerContact.Fax,
                partnerContact.Website,
                partnerContact.Latitude,
                partnerContact.Longitude,
                partnerContact.Active,
                userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<bool> DeletePartnerContactAsync(int partnerContactId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeletePartnerContact;
            await connection.ExecuteAsync(procName, new
            {
                Id = partnerContactId,
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return true;
        }

        public async Task<PartnerContactDomain> GetPartnerContactByIdAsync(int partnerId, int partnerContactId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerContactById;
            return await connection.QueryFirstOrDefaultAsync<PartnerContactDomain>(procName, new { partnerId, partnerContactId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<List<PartnerContactDomain>> GetPartnerContactsAsync(int partnerId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerContacts;
            var result = await connection.QueryAsync<PartnerContactDomain>(procName, new { partnerId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result.AsList();
        }
    }
}
