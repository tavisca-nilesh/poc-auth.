﻿
namespace MADA.ERP.Sales.Storage.Data
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;

    public class LocationRepository : ILocationRepository
    {
        private readonly IConnectionFactory _connectionFactory;
        public LocationRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> AddOrUpdateLocationAsync(LocationContract location, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertLocation;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                location.Id,
                location.Name,
                location.SLName,
                location.ParentWareHouseId,
                LocationTypeId = location.LocationType,
                location.IsScrap,
                location.IsReturn,
                location.Barcode,
                location.OwnerId,
                userId,
                location.Active
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<bool> DeleteLocationAsync(int locationId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeleteLocation;
            await connection.ExecuteAsync(procName, new
            {
                Id = locationId,
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return true;
        }

        public async Task<SuccessFailureDomain> DeleteLocationsByIdsAsync(List<int> locationIds, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeleteLocationsByIds;
            var result = await connection.QueryMultipleAsync(procName, new
            {
                Ids = locationIds.ConvertToDataTable("Value"),
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var failedIds = await result.ReadAsync<int>().ConfigureAwait(false);
            return new SuccessFailureDomain
            {
                SuccessIds = locationIds.Where(ids => !failedIds.Contains(ids)).ToList(),
                FailureIds = failedIds.ToList()
            };
        }

        public async Task<LocationDomain> GetLocationByIdAsync(int locationId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetLocationById;
            return await connection.QueryFirstOrDefaultAsync<LocationDomain>(procName, new { locationId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<LocationListDomain> GetLocationListAsync(SearchContract searchContract)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetLocations;
            var result = await connection.QueryMultipleAsync(procName, searchContract, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var locations = await result.ReadAsync<LocationDomain>().ConfigureAwait(false);
            var pagination = await result.ReadAsync<PaginationInfo>().ConfigureAwait(false);
            return new LocationListDomain
            {
                Locations = locations.ToList(),
                Pagination = pagination.FirstOrDefault()
            };
        }
    }
}
