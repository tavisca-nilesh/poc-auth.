﻿
namespace MADA.ERP.Sales.Storage.Data
{
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    public class SalesOrderRepository : ISalesOrderRepository
    {
        private readonly IConnectionFactory _connectionFactory;
        public SalesOrderRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> AddOrUpdateSalesOrderAsync(SalesOrderContract salesOrder, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertSalesOrder;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                salesOrder.Id,
                salesOrder.CustomerReference,
                salesOrder.Status,
                salesOrder.QuotationDate,
                salesOrder.ExpirationDate,
                salesOrder.ConfirmationDate,
                salesOrder.SalesPersonId,
                salesOrder.PartnerId,
                salesOrder.InvoiceAddressId,
                salesOrder.DeliveryAddressId,
                salesOrder.PricelistId,
                salesOrder.CurrencyId,
                salesOrder.ExchangeRate,
                salesOrder.Total,
                salesOrder.DiscountAmt,
                salesOrder.TermsAndConditions,
                salesOrder.PaymentTermsId,
                salesOrder.LocationId,
                salesOrder.ShippingPolicyId,
                salesOrder.VersionId,
                salesOrder.IsVersion,
                userId,
                SalesOrderLine = salesOrder.SalesOrderLine.ToXMLString("SalesOrderLine", "Orders")
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<bool> DeleteSalesOrderAsync(int salesOrderId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeleteSalesOrder;
            await connection.ExecuteAsync(procName, new
            {
                Id = salesOrderId,
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return true;
        }

        public async Task<SalesOrderDomain> GetSalesOrderByIdAsync(int salesOrderId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetSalesOrderById;
            var result = await connection.QueryMultipleAsync(procName, new { Id= salesOrderId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var salesOrders = await result.ReadFirstOrDefaultAsync<SalesOrderDomain>().ConfigureAwait(false);
            if (salesOrders != null)
            {
                var salesOrderLines = await result.ReadAsync<SalesOrderLineDomain>().ConfigureAwait(false);
                salesOrders.SalesOrderLine = salesOrderLines.ToList();
            }
            return salesOrders;
        }

        public async Task<SalesOrderListDomain> GetSalesOrderListAsync(SalesOrderSearchContract searchContract)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetSalesOrders;
            var result = await connection.QueryMultipleAsync(procName, searchContract, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var salesOrders = await result.ReadAsync<SalesOrderDomain>().ConfigureAwait(false);
            var pagination = await result.ReadAsync<PaginationInfo>().ConfigureAwait(false);
            var salesOrderLines = await result.ReadAsync<SalesOrderLineDomain>().ConfigureAwait(false);
            SalesOrderListDomain salesOrder = new SalesOrderListDomain
            {
                SalesOrders = salesOrders.ToList(),
                Pagination = pagination.FirstOrDefault()
            };
            salesOrder.SalesOrders.ForEach(so => so.SalesOrderLine = salesOrderLines.Where(sol => sol.SalesOrderId == so.Id).ToList());
            return salesOrder;
        }

        public async Task<int> UpdateSalesOrderStatus(int salesOrderId, SalesOrderStatus salesOrderStatus, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpdateSalesOrderStatus;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                Id = salesOrderId,
                Status = salesOrderStatus,
                userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<UnitPriceDomain> GetUnitPrice(UnitPriceContract unitPriceContract)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetUnitPrice;
            return await connection.QueryFirstOrDefaultAsync<UnitPriceDomain>(procName, unitPriceContract, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<SuccessFailureDomain> DeleteSalesOrdersByIdsAsync(List<int> salesOrderIds, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeleteSalesOrdersByIds;
            var result = await connection.QueryMultipleAsync(procName, new
            {
                Ids = salesOrderIds.ConvertToDataTable("Value"),
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var failedIds = await result.ReadAsync<int>().ConfigureAwait(false);
            return new SuccessFailureDomain
            {
                SuccessIds = salesOrderIds.Where(ids => !failedIds.Contains(ids)).ToList(),
                FailureIds = failedIds.ToList()
            };
        }
    }
}
