﻿namespace MADA.ERP.Sales.Storage.Data
{
    using System.Collections.Generic;
    using System.Data;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;

    public class PartnerAccountRepository : IPartnerAccountRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public PartnerAccountRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> AddOrUpdatePartnerAccountAsync(PartnerAccountContract partnerAccount, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertPartnerAccount;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                partnerAccount.Id,
                partnerAccount.PartnerId,
                partnerAccount.CustomerTermsId,
                partnerAccount.VendorTermsId,
                partnerAccount.DegreeOfTrustId,
                partnerAccount.AccountRecId,
                partnerAccount.AccountPayId,
                partnerAccount.Active,
                userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<bool> DeletePartnerAccountAsync(int partnerAccountId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeletePartnerAccount;
            await connection.ExecuteAsync(procName, new
            {
                Id = partnerAccountId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return true;
        }

        public async Task<PartnerAccountDomain> GetPartnerAccountByIdAsync(int partnerId, int partnerAccountId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerAccountById;
            return await connection.QueryFirstOrDefaultAsync<PartnerAccountDomain>(procName, new { partnerId, partnerAccountId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<List<PartnerAccountDomain>> GetPartnerAccountsAsync(int partnerId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerAccounts;
            var result = await connection.QueryAsync<PartnerAccountDomain>(procName, new { partnerId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result.AsList();
        }
    }
}
