﻿namespace MADA.ERP.Sales.Storage.Data
{
    using System.Data;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;

    public class PartnerSalesPurchasesRepository : IPartnerSalesPurchasesRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public PartnerSalesPurchasesRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> UpdatePartnerSalesPurchasesAsync(PartnerSalesPurchasesContract partnerSalesPurchases, int partnerId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpdatePartnerSalesPurchases;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                partnerId,
                partnerSalesPurchases.Barcode,
                partnerSalesPurchases.InternalRef,
                partnerSalesPurchases.IsCustomer,
                partnerSalesPurchases.IsPreferEReceipt,
                partnerSalesPurchases.IsVendor,
                partnerSalesPurchases.PriceListId,
                partnerSalesPurchases.SalesPersonId,
                partnerSalesPurchases.SupplierCurrencyId,
                userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<PartnerSalesPurchasesDomain> GetPartnerSalesPurchasesAsync(int partnerId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerSalesPurchases;
            return await connection.QueryFirstOrDefaultAsync<PartnerSalesPurchasesDomain>(procName, new { partnerId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }
    }
}