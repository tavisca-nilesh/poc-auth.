
namespace MADA.ERP.Sales.Storage.Data
{
    using Dapper;
    using MADA.ERP.Sales.Domain.Interfaces;
    using System.Data.SqlClient;
    using System.Diagnostics.CodeAnalysis;
    using System.Threading.Tasks;
    using System.Collections.Generic;
    using MADA.ERP.Sales.Contract.Models;
    using System.Linq;

    public class DataRepository : IDataRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public DataRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<List<SampleContract>> GetSampleListAsync()
        {
            using (var connection = _connectionFactory.GetDbConnection())
            {
                var selectQuery = $@"select 1 Id, 'Test' as Name";

                var result = await connection.QueryAsync<SampleContract>(selectQuery).ConfigureAwait(false);
                return result.ToList();
            }
        }

        public bool TryConnect(out string message)
        {
            using (var connection = _connectionFactory.GetDbConnection())
            {
                try
                {
                    connection.Execute("SELECT TOP 1 1");
                    message = null;
                    return true;
                }
                catch (SqlException ex)
                {
                    message = $"Failed to connect successfully to database '{connection.Database}'.\n{ex.GetType().Name}: {ex.Message}";
                    return false;
                }
            }
        }
    }
}
