﻿
namespace MADA.ERP.Sales.Storage.Data
{
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;

    public class PriceListRepository : IPriceListRepository
    {
        private readonly IConnectionFactory _connectionFactory;
        public PriceListRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }
        public async Task<int> AddOrUpdatePriceListAsync(PriceListContract priceList, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertPriceList;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                priceList.Id,
                priceList.Name,
                priceList.TypeOfPriceList,
                priceList.LocationId,
                priceList.StartDate,
                priceList.EndDate,
                priceList.IsPromotional,
                priceList.IsUpdateTransValue,
                priceList.IsUpdatePost,
                priceList.IsPublic,
                userId,
                priceList.Active
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<bool> DeletePriceListAsync(int priceListId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeletePriceList;
            await connection.ExecuteAsync(procName, new
            {
                Id = priceListId,
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return true;
        }

        public async Task<SuccessFailureDomain> DeletePriceListsByIdsAsync(List<int> priceListIds, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeletePriceListsByIds;
            var result = await connection.QueryMultipleAsync(procName, new
            {
                Ids = priceListIds.ConvertToDataTable("Value"),
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var failedIds = await result.ReadAsync<int>().ConfigureAwait(false);
            return new SuccessFailureDomain
            {
                SuccessIds = priceListIds.Where(ids => !failedIds.Contains(ids)).ToList(),
                FailureIds = failedIds.ToList()
            };
        }

        public async Task<PriceListDomain> GetPriceListByIdAsync(int PriceListId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPriceListById;
            var result = await connection.QueryMultipleAsync(procName, new { PriceListId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var priceListDomains = await result.ReadFirstOrDefaultAsync<PriceListDomain>().ConfigureAwait(false);
            return priceListDomains;
        }

        public async Task<PriceListDomainList> GetPriceListsAsync(SearchContract searchContract)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPriceLists;
            var result = await connection.QueryMultipleAsync(procName, new
            {
                searchContract.SearchTerm,
                searchContract.PageNumber,
                searchContract.PageSize,
                searchContract.Active,
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var priceListDomains = await result.ReadAsync<PriceListDomain>().ConfigureAwait(false);
            var pagination = await result.ReadAsync<PaginationInfo>().ConfigureAwait(false);
            PriceListDomainList priceList = new PriceListDomainList
            {
                PriceLists = priceListDomains.ToList(),
                Pagination = pagination.FirstOrDefault()
            };
            return priceList;
        }
    }
}
