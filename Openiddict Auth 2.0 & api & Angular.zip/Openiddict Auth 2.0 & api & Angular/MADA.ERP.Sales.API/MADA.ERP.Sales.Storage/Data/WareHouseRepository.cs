﻿
namespace MADA.ERP.Sales.Storage.Data
{
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;

    public class WareHouseRepository : IWareHouseRepository
    {
        private readonly IConnectionFactory _connectionFactory;
        public WareHouseRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> AddOrUpdateWareHouseAsync(WareHouseContract wareHouse, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertWareHouse;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                wareHouse.Id,
                wareHouse.Name,
                wareHouse.SLName,
                userId,
                wareHouse.Active
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<bool> DeleteWareHouseAsync(int wareHouseId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeleteWareHouse;
            await connection.ExecuteAsync(procName, new
            {
                Id = wareHouseId,
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return true;
        }

        public async Task<WareHouseListDomain> GetWareHouseListAsync(SearchContract searchContract)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetWareHouses;
            var result = await connection.QueryMultipleAsync(procName, searchContract, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var wareHouses = await result.ReadAsync<WareHouseDomain>().ConfigureAwait(false);
            var pagination = await result.ReadAsync<PaginationInfo>().ConfigureAwait(false);
            return new WareHouseListDomain
            {
                WareHouses = wareHouses.ToList(),
                Pagination = pagination.FirstOrDefault()
            };
        }

        public async Task<WareHouseDomain> GetWareHouseByIdAsync(int wareHouseId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetWareHouseById;
            return await connection.QueryFirstOrDefaultAsync<WareHouseDomain>(procName, new { wareHouseId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<SuccessFailureDomain> DeleteWarehousesByIdsAsync(List<int> warehouseIds, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeleteWarehousesByIds;
            var result = await connection.QueryMultipleAsync(procName, new
            {
                Ids = warehouseIds.ConvertToDataTable("Value"),
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var failedIds = await result.ReadAsync<int>().ConfigureAwait(false);
            return new SuccessFailureDomain
            {
                SuccessIds = warehouseIds.Where(ids => !failedIds.Contains(ids)).ToList(),
                FailureIds = failedIds.ToList()
            };
        }
    }
}
