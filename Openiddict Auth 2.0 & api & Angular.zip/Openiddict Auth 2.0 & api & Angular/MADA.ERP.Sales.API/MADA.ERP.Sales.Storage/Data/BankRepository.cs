﻿
namespace MADA.ERP.Sales.Storage.Data
{
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;
    public class BankRepository : IBankRepository
    {
        private readonly IConnectionFactory _connectionFactory;
        public BankRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> AddOrUpdateBankAsync(BankContract bank, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertBank;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                bank.Id,
                bank.Name,
                bank.SLName,
                userId,
                bank.Active
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<bool> DeleteBankAsync(int bankId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeleteBank;
            await connection.ExecuteAsync(procName, new
            {
                Id = bankId,
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return true;
        }

        public async Task<BankListDomain> GetBankListAsync(SearchContract searchContract)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetBanks;
            var result = await connection.QueryMultipleAsync(procName, searchContract, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var Banks = await result.ReadAsync<BankDomain>().ConfigureAwait(false);
            var pagination = await result.ReadAsync<PaginationInfo>().ConfigureAwait(false);
            return new BankListDomain
            {
                Banks = Banks.ToList(),
                Pagination = pagination.FirstOrDefault()
            };
        }

        public async Task<BankDomain> GetBankByIdAsync(int bankId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetBankById;
            return await connection.QueryFirstOrDefaultAsync<BankDomain>(procName, new { Id = bankId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<SuccessFailureDomain> DeleteBanksByIdsAsync(List<int> banksIds, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeleteBanksByIds;
            var result = await connection.QueryMultipleAsync(procName, new
            {
                Ids = banksIds.ConvertToDataTable("Value"),
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var failedIds = await result.ReadAsync<int>().ConfigureAwait(false);
            return new SuccessFailureDomain
            {
                SuccessIds = banksIds.Where(ids => !failedIds.Contains(ids)).ToList(),
                FailureIds = failedIds.ToList()
            };
        }
    }
}
