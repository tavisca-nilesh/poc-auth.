﻿namespace MADA.ERP.Sales.Storage.Data
{
    using System.Collections.Generic;
    using System.Data;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;

    public class PartnerBankRepository : IPartnerBankRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public PartnerBankRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> AddOrUpdatePartnerBankAsync(PartnerBankContract partnerBank, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertPartnerBank;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                partnerBank.Id,
                partnerBank.AccountNumber,
                partnerBank.PartnerId,
                partnerBank.BankId,
                partnerBank.CurrencyId,
                partnerBank.CompanyId,
                partnerBank.Active,
                userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<bool> DeletePartnerBankAsync(int partnerBankId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeletePartnerBank;
            await connection.ExecuteAsync(procName, new
            {
                Id = partnerBankId,
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return true;
        }

        public async Task<PartnerBankDomain> GetPartnerBankByIdAsync(int partnerId, int bankId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerBankById;
            return await connection.QueryFirstOrDefaultAsync<PartnerBankDomain>(procName, new { partnerId, bankId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<List<PartnerBankDomain>> GetPartnerBanksAsync(int partnerId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerBanks;
            var result = await connection.QueryAsync<PartnerBankDomain>(procName, new { partnerId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result.AsList();
        }
    }
}
