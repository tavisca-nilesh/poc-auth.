﻿
namespace MADA.ERP.Sales.Storage.Data
{
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;

    public class PaymentTermRepository : IPaymentTermRepository
    {
        private readonly IConnectionFactory _connectionFactory;
        public PaymentTermRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> AddOrUpdatePaymentTermAsync(PaymentTermContract paymentTerm, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertPaymentTerm;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                paymentTerm.Id,
                paymentTerm.Name,
                paymentTerm.Description,
                paymentTerm.NoOfDays,
                userId,
                paymentTerm.Active
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<bool> DeletePaymentTermAsync(int paymentTermId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeletePaymentTerm;
            await connection.ExecuteAsync(procName, new
            {
                Id = paymentTermId,
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return true;
        }

        public async Task<SuccessFailureDomain> DeletePaymentTermsByIdsAsync(List<int> paymentTermIds, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeletePaymentTermsByIds;
            var result = await connection.QueryMultipleAsync(procName, new
            {
                Ids = paymentTermIds.ConvertToDataTable("Value"),
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var failedIds = await result.ReadAsync<int>().ConfigureAwait(false);
            return new SuccessFailureDomain
            {
                SuccessIds = paymentTermIds.Where(ids => !failedIds.Contains(ids)).ToList(),
                FailureIds = failedIds.ToList()
            };
        }

        public async Task<PaymentTermDomain> GetPaymentTermByIdAsync(int paymentTermId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPaymentTermById;
            return await connection.QueryFirstOrDefaultAsync<PaymentTermDomain>(procName, new { paymentTermId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<PaymentTermListDomain> GetPaymentTermListAsync(SearchContract searchContract)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPaymentTerms;
            var result = await connection.QueryMultipleAsync(procName, searchContract, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var paymentTerms = await result.ReadAsync<PaymentTermDomain>().ConfigureAwait(false);
            var pagination = await result.ReadAsync<PaginationInfo>().ConfigureAwait(false);
            return new PaymentTermListDomain
            {
                PaymentTerms = paymentTerms.ToList(),
                Pagination = pagination.FirstOrDefault()
            };
        }
    }
}
