﻿namespace MADA.ERP.Sales.Storage.Data
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using Dapper;
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Interfaces;
    using MADA.ERP.Sales.Domain.Models;

    public class PartnerRepository : IPartnerRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public PartnerRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<int> AddOrUpdatePartnerAsync(PartnerContract partner, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertPartner;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                partner.Id,
                partner.Name,
                partner.SLName,
                partner.DisplayName,
                partner.TitleId,
                partner.CompanyId,
                partner.LangId,
                partner.TimezoneId,
                partner.TIN,
                partner.Website,
                partner.CreditLimit,
                partner.Active,
                partner.IsEmployee,
                partner.JobPosition,
                partner.Street,
                partner.Street2,
                partner.Zip,
                partner.CityId,
                partner.Email,
                partner.Phone,
                partner.Fax,
                partner.Mobile,
                partner.IsCompany,
                partner.PartnerType,
                partner.PartnerPageType,
                userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<bool> DeletePartnerAsync(int partnerId, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeletePartner;
            await connection.ExecuteAsync(procName, new
            {
                Id = partnerId,
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return true;
        }

        public async Task<PartnerListDomain> GetPartnerListAsync(PartnerSearchContract searchContract)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerList;
            var result = await connection.QueryMultipleAsync(procName, searchContract, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var partners = await result.ReadAsync<PartnerDomain>().ConfigureAwait(false);
            var pagination = await result.ReadAsync<PaginationInfo>().ConfigureAwait(false);
            return new PartnerListDomain
            {
                Partners = partners.ToList(),
                Pagination = pagination.FirstOrDefault()
            };
        }

        public async Task<int> UpdatePartnerNoteAsync(int partnerId, string notes, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpdatePartnerNotes;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                partnerId,
                notes,
                userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<PartnerFullDomain> GetPartnerByIdAsync(int partnerId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerById;
            var result = await connection.QueryMultipleAsync(procName, new { partnerId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var partnerFullDomain = await result.ReadFirstOrDefaultAsync<PartnerFullDomain>().ConfigureAwait(false);
            if (partnerFullDomain != null)
            {
                partnerFullDomain.Banks = (await result.ReadAsync<RelationalDomain>().ConfigureAwait(false)).ToList();
                partnerFullDomain.Contacts = (await result.ReadAsync<RelationalDomain>().ConfigureAwait(false)).ToList();
            }
            return partnerFullDomain;
        }

        public async Task<int> AddOrUpdatePartnerIconAsync(PartnerIconContract partnerIcon, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpsertPartnerIcon;
            var result = await connection.QueryAsync<int>(procName, new
            {
                partnerIcon.Id,
                partnerIcon.Icon,
                UserId = userId,
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result.FirstOrDefault();
        }

        public async Task<PartnerNoteDomain> GetPartnerNoteAsync(int partnerId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerNotes;
            return await connection.QueryFirstOrDefaultAsync<PartnerNoteDomain>(procName, 
                new { PartnerId = partnerId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<int> UpdatePartnerStatusAsync(int id, bool status, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpdatePartnerStatus;
            var result = await connection.ExecuteScalarAsync<int>(procName, new
            {
                id,
                status,
                userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            return result;
        }

        public async Task<PartnerListDomain> GetPartnerListByTypeAsync(PartnerSearchType partnerSearchType, PartnerSearchContract searchContract)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerListByType;
            var result = await connection.QueryMultipleAsync(procName, new {
                searchContract.SearchTerm,
                searchContract.PageNumber,
                searchContract.PageSize,
                searchContract.Active,
                searchContract.IsCompany,
                partnerSearchType 
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var partners = await result.ReadAsync<PartnerDomain>().ConfigureAwait(false);
            var pagination = await result.ReadAsync<PaginationInfo>().ConfigureAwait(false);
            return new PartnerListDomain
            {
                Partners = partners.ToList(),
                Pagination = pagination.FirstOrDefault()
            };
        }

        public async Task<int> UpdatePartnerAssignationAsync(int partnerId, PartnerAssignationContract partnerAssignation, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.UpdatePartnerAssignation;
            return await connection.ExecuteScalarAsync<int>(procName, new { 
                Id = partnerId, partnerAssignation.Latitude, partnerAssignation.Longitude, UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<PartnerAssignationDomain> GetPartnerAssignationAsync(int partnerId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.GetPartnerAssignation;
            return await connection.QueryFirstOrDefaultAsync<PartnerAssignationDomain>(procName, new { Id = partnerId }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
        }

        public async Task<SuccessFailureDomain> DeletePartnersByIdsAsync(List<int> partnerIds, int userId)
        {
            using var connection = _connectionFactory.GetDbConnection();
            var procName = StoredProcedureConstants.DeletePartnersByIds;
            var result = await connection.QueryMultipleAsync(procName, new
            {
                Ids = partnerIds.ConvertToDataTable("Value"),
                UserId = userId
            }, null, null, CommandType.StoredProcedure).ConfigureAwait(false);
            var failedIds = await result.ReadAsync<int>().ConfigureAwait(false);
            return new SuccessFailureDomain
            {
                SuccessIds = partnerIds.Where(ids => !failedIds.Contains(ids)).ToList(),
                FailureIds = failedIds.ToList()
            };
        }
    }
}
