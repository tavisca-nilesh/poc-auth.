﻿namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;

    [Route("api/v1/Partners/{partnerId}/Accounts")]
    [ApiController]
    public class PartnerAccountsController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<PartnerAccountsController> _logger;

        public PartnerAccountsController(IMessages messages, ILogger<PartnerAccountsController> logger)
        {
            _messages = messages;
            _logger = logger;
        }

        // GET: api/v1/Partners/5/Accounts
        [HttpGet]
        public async Task<IActionResult> GetPartnerAccountsAsync(int partnerId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            var query = new GetPartnerAccountsQuery
            { PartnerId = partnerId };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        // GET: api/v1/Partners/5/Accounts/9
        [HttpGet("{partnerAccountId}")]
        public async Task<IActionResult> GetPartnerAccountById(int partnerId, int partnerAccountId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");
            if (partnerAccountId < 1)
                return Error("Invalid Account Id");

            var query = new GetPartnerAccountQuery
            {
                PartnerId = partnerId,
                PartnerAccountId = partnerAccountId
            };

            var partnerAccount = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(partnerAccount);
        }

        // POST: api/v1/Partners/5/Accounts
        [HttpPost]
        public async Task<IActionResult> AddPartnerAccountAsync(int partnerId, [FromBody] PartnerAccountContract accountContract)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            if (accountContract == null)
                return Error("Invalid Payload");

            _logger.LogInformation("Adding Partner");

            accountContract.Id = 0;
            accountContract.PartnerId = partnerId;

            var command = new AddOrUpdatePartnerAccountCommand
            {
                PartnerAccount = accountContract,
                UserId = GetUserIdFromClaim()
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // PUT: api/v1/Partners/5/Accounts
        [HttpPut]
        public async Task<IActionResult> UpdatePartnerAccountAsync(int partnerId, [FromBody] PartnerAccountContract accountContract)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            if (accountContract == null)
                return Error("Invalid Payload");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Updating PartnerAccount: {accountContract.Id} for Partner: {partnerId}, Requested By: {userId}");

            var command = new AddOrUpdatePartnerAccountCommand
            {
                PartnerAccount = accountContract,
                UserId = userId
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // DELETE: api/v1/Partners/5/Accounts/9
        [HttpDelete("{partnerAccountId}")]
        public async Task<IActionResult> DeletePartnerAccountAsync(int partnerId, int partnerAccountId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner Id");
            if (partnerAccountId < 1)
                return Error("Invalid Account Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Deleting PartnerAccount: {partnerAccountId} for Partner: {partnerId}, Requested By: {userId}");

            var command = new DeletePartnerAccountCommand
            {
                Id = partnerAccountId,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }
    }
}