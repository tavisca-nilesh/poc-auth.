﻿namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;

    [Route("api/v1/Partners/{partnerId}/Banks")]
    [ApiController]
    public class PartnerBanksController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<PartnersController> _logger;

        public PartnerBanksController(IMessages messages, ILogger<PartnersController> logger)
        {
            _messages = messages;
            _logger = logger;
        }

        // GET: api/v1/Partners/5/Banks
        [HttpGet]
        public async Task<IActionResult> GetPartnerBanksAsync(int partnerId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            var query = new GetPartnerBanksQuery
            { PartnerId = partnerId };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        // GET: api/v1/Partners/5/Banks/9
        [HttpGet("{bankId}")]
        public async Task<IActionResult> GetPartnerBankById(int partnerId, int bankId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            if (bankId < 1)
                return Error("Invalid Bank ID");

            var query = new GetPartnerBankQuery
            {
                PartnerId = partnerId,
                BankId = bankId
            };

            var partnerBank = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(partnerBank);
        }

        // POST: api/v1/Partners/5/Banks
        [HttpPost]
        public async Task<IActionResult> AddPartnerBankAsync(int partnerId, [FromBody] PartnerBankContract BankContract)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            if (BankContract == null)
                return Error("Invalid Payload");

            _logger.LogInformation("Adding Partner");

            BankContract.Id = 0;
            BankContract.PartnerId = partnerId;

            var command = new AddOrUpdatePartnerBankCommand
            {
                PartnerBank = BankContract,
                UserId = GetUserIdFromClaim()
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // PUT: api/v1/Partners/5/Banks
        [HttpPut]
        public async Task<IActionResult> UpdatePartnerBankAsync(int partnerId, [FromBody] PartnerBankContract BankContract)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            if (BankContract == null)
                return Error("Invalid Payload");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Updating PartnerBank: {BankContract.Id} for Partner: {partnerId}, Requested By: {userId}");

            var command = new AddOrUpdatePartnerBankCommand
            {
                PartnerBank = BankContract,
                UserId = userId
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // DELETE: api/v1/Partners/5/Banks/9
        [HttpDelete("{partnerBankId}")]
        public async Task<IActionResult> DeletePartnerBankAsync(int partnerId, int partnerBankId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner Id");
            if (partnerBankId < 1)
                return Error("Invalid Bank Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Deleting PartnerBank: {partnerBankId} for Partner: {partnerId}, Requested By: {userId}");

            var command = new DeletePartnerBankCommand
            {
                Id = partnerBankId,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }
    }
}