﻿
namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Linq;

    [Route("api/v1/[controller]")]

    [ApiController]
    public class BanksController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<BanksController> _logger;
        public BanksController(IMessages messages, ILogger<BanksController> logger)
        {
            _logger = logger;
            _messages = messages;
        }

        // GET: api/v1/Banks
        [HttpGet]
        public async Task<IActionResult> GetBanksAsync([FromQuery] SearchContract searchContract)
        {
            if (searchContract == null)
                return Error("Invalid Input");
            else if (searchContract.PageNumber < 1)
                return Error("Invalid Page Number");
            else if (searchContract.PageSize < 1)
                return Error("Invalid Page Size");

            _logger.LogInformation("GetBanksAsync Called.");

            var query = new GetBanksQuery
            {
                SearchContract = searchContract
            };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        // GET: api/v1/Banks/5
        [HttpGet("{bankId}")]
        public async Task<IActionResult> GetBankAsync(int bankId)
        {
            if (bankId < 1)
                return Error("Invalid Bank Id");

            _logger.LogInformation("GetBankAsync Called.");

            var query = new GetBankQuery
            {
                BankId = bankId
            };

            var result = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(result);
        }

        // POST: api/v1/Banks
        [HttpPost]
        public async Task<IActionResult> AddBankAsync([FromBody] BankContract bank)
        {
            if (bank == null)
                return Error("Invalid Payload");

            _logger.LogInformation("Adding Bank");

            bank.Id = 0;
            var command = new AddOrUpdateBankCommand
            {
                Bank = bank,
                UserId = GetUserIdFromClaim()
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // PUT: api/v1/Banks
        [HttpPut]
        public async Task<IActionResult> UpdatePartnerAsync([FromBody] BankContract bank)
        {
            if (bank == null)
                return Error("Invalid Payload");

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Updating Bank: {bank.Id}, Requested By: {userID}");

            var command = new AddOrUpdateBankCommand
            {
                Bank = bank,
                UserId = userID
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // DELETE: api/v1/Banks/5
        [HttpDelete("{bankId}")]
        public async Task<IActionResult> DeleteBankAsync(int bankId)
        {
            if (bankId < 1)
                return Error("Invalid Bank Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Deleting Bank : {bankId}, Requested By: {userId}");

            var command = new DeleteBankCommand
            {
                Id = bankId,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPost("deleteByIds")]
        public async Task<IActionResult> DeleteBanksAsync([FromBody] List<int> idsList)
        {
            if (idsList == null)
            {
                return Error("Invalid Payload");
            }
            if (!idsList.Any())
            {
                return Error("Empty Bank Ids List");
            }
            var userId = GetUserIdFromClaim();
            _logger.LogInformation($"Deleting Banks: {string.Join(",", idsList)}, Requested By:{userId}");

            var command = new DeleteBanksByIdsCommand
            {
                Ids = idsList,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }
    }
}