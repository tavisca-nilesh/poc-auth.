﻿namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;
    using MADA.ERP.Sales.Common;
    using System.Collections.Generic;

    [Route("api/v1/[controller]")]
    [ApiController]
    public class PartnersController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<PartnersController> _logger;
        public PartnersController(IMessages messages, ILogger<PartnersController> logger)
        {
            _logger = logger;
            _messages = messages;
        }

        // GET: api/v1/Partners
        [HttpGet]
        public async Task<IActionResult> GetPartnersAsync([FromQuery] PartnerSearchContract searchContract)
        {
            if (searchContract == null)
                return Error("Invalid Input");
            else if (searchContract.PageNumber < 1)
                return Error("Invalid Page Number");
            else if (searchContract.PageSize < 1)
                return Error("Invalid Page Size");

            _logger.LogInformation("GetPartnersAsync Called.");

            var query = new GetPartnerListQuery
            {
                SearchContract = searchContract
            };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        // GET: api/v1/Partners/5
        [HttpGet("{partnerId}")]
        public async Task<IActionResult> GetPartnerById(int partnerId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner Id");

            _logger.LogInformation("GetPartnerById Called.");

            var query = new GetPartnerQuery
            {
                PartnerId = partnerId
            };

            var partner = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(partner);
        }

        // POST: api/v1/Partners
        [HttpPost]
        public async Task<IActionResult> AddPartnerAsync([FromBody] PartnerContract partner)
        {
            if (partner == null)
                return Error("Invalid Payload");

            _logger.LogInformation("Adding Partner");

            partner.Id = 0;
            var command = new AddOrUpdatePartnerCommand
            {
                Partner = partner,
                UserId = GetUserIdFromClaim()
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // PUT: api/v1/Partners
        [HttpPut]
        public async Task<IActionResult> UpdatePartnerAsync([FromBody] PartnerContract partner)
        {
            if (partner == null)
                return Error("Invalid Payload");

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Updating Partner: {partner.Id}, Requested By: {userID}");

            var command = new AddOrUpdatePartnerCommand
            {
                Partner = partner,
                UserId = userID
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // DELETE: api/v1/Partners/5
        [HttpDelete("{partnerId}")]
        public async Task<IActionResult> DeletePartnerAsync(int partnerId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Deleting Partner: {partnerId}, Requested By: {userId}");

            var command = new DeletePartnerCommand
            {
                Id = partnerId,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPost("{partnerId}/Note")]
        public async Task<IActionResult> UpdateNote(int partnerId, string note)
        {
            if (partnerId < 1)
                return Error("Invalid Partner Id");

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Updating Notes for Partner: {partnerId}, Requested By: {userID}");

            var command = new UpdatePartnerNoteCommand
            {
                PartnerId = partnerId,
                Note = note,
                UserId = userID
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPost]
        [Route("{partnerId}/Icon")]
        public async Task<IActionResult> UpsertPartnerIconAsync(int partnerId)
        {
            if (partnerId < 1)
            {
                return Error("Invalid Partner Id");
            }
            var _files = Request.Form.Files;

            PartnerIconContract partnerIcon = new PartnerIconContract
            {
                Id = partnerId,
            };

            if (_files.Any())
            {
                var _file = Request.Form.Files[0];
                using var ms = new MemoryStream();
                _file.CopyTo(ms);
                partnerIcon.Icon = ms.ToArray();
            }

            _logger.LogInformation("Updating Partner icon");

            var command = new AddOrUpdatePartnerIconCommand
            {
                PartnerIcon = partnerIcon,
                UserId = GetUserIdFromClaim()
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // GET: api/v1/Partners/{partnerId}/Note
        [HttpGet("{partnerId}/Note")]
        public async Task<IActionResult> GetPartnerNote(int partnerId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner Id");

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Getting Notes for Partner: {partnerId}, Requested By: {userID}");

            var command = new GetPartnerNoteQuery
            {
                PartnerId = partnerId
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPut("{partnerId}/Status")]
        public async Task<IActionResult> UpdatePartnerStatus(int partnerId, [FromBody] bool active)
        {
            if (partnerId < 1)
                return Error("Invalid Partner Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Updating Status for Partner: {partnerId}, Requested By: {userId}");

            var command = new UpdatePartnerStatusCommand
            {
                Id = partnerId,
                Status = active,
                UserId = userId
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // GET: api/v1/Partners/ByType
        [HttpGet("bytype/{partnerSearchType}")]
        public async Task<IActionResult> GetPartnersByTypeAsync(int partnerSearchType, [FromQuery] PartnerSearchContract searchContract)
        {
            if (partnerSearchType < 1)
                return Error("Invalid Input");
            if (searchContract == null)
                return Error("Invalid Input");
            else if (searchContract.PageNumber < 1)
                return Error("Invalid Page Number");
            else if (searchContract.PageSize < 1)
                return Error("Invalid Page Size");

            _logger.LogInformation("GetPartnersByTypeAsync Called.");

            var query = new GetPartnerListByTypeQuery
            {
                PartnerSearchType = (PartnerSearchType)partnerSearchType,
                SearchContract = searchContract
            };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        // PUT: api/v1/Partners/{partnerId}/partner-assignation
        [HttpPut("{partnerId}/partner-assignation")]
        public async Task<IActionResult> UpdatePartnerAsync(int partnerId, [FromBody] PartnerAssignationContract partnerAssignation)
        {
            if (partnerId < 0)
                return Error("Invalid PartnerId");

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Updating Partner: {partnerId}, Requested By: {userID}");

            var command = new UpdatePartnerAssignationCommand
            {
                PartnerId = partnerId,
                PartnerAssignation = partnerAssignation,
                UserId = userID
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // GET: api/v1/Partners/{partnerId}/partner-assignation
        [HttpGet("{partnerId}/partner-assignation")]
        public async Task<IActionResult> GetPartnerAssignationAsync(int partnerId)
        {
            var command = new GetPartnerAssignationCommand
            {
                PartnerId = partnerId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPost("deleteByIds")]
        public async Task<IActionResult> DeletePartnersAsync([FromBody] List<int> idsList)
        {
            if (idsList == null)
            {
                return Error("Invalid Payload");
            }
            if (!idsList.Any())
            {
                return Error("Empty Partner Ids List");
            }
            var userId = GetUserIdFromClaim();
            _logger.LogInformation($"Deleting Partners: {string.Join(",", idsList)}, Requested By:{userId}");

            var command = new DeletePartnersByIdsCommand
            {
                Ids = idsList,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }
    }
}
