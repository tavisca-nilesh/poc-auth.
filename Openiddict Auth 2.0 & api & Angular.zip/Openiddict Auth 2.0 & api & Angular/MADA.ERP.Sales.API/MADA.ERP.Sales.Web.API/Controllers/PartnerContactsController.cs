﻿namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;

    [Route("api/v1/Partners/{partnerId}/Contacts")]
    [ApiController]
    public class PartnerContactsController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<PartnerContactsController> _logger;

        public PartnerContactsController(IMessages messages, ILogger<PartnerContactsController> logger)
        {
            _messages = messages;
            _logger = logger;
        }

        // GET: api/v1/Partners/5/Contacts
        [HttpGet]
        public async Task<IActionResult> GetPartnerContactsAsync(int partnerId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            var query = new GetPartnerContactsQuery
            { PartnerId = partnerId };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        // GET: api/v1/Partners/5/Contacts/9
        [HttpGet("{partnerContactId}")]
        public async Task<IActionResult> GetPartnerContactById(int partnerId, int partnerContactId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");
            if (partnerContactId < 1)
                return Error("Invalid Contact Id");

            var query = new GetPartnerContactQuery
            { 
                PartnerId = partnerId,
                PartnerContactId = partnerContactId
            };

            var partnerContact = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(partnerContact);
        }

        // POST: api/v1/Partners/5/Contacts
        [HttpPost]
        public async Task<IActionResult> AddPartnerContactAsync(int partnerId, [FromBody] PartnerContactContract contactContract)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            if (contactContract == null)
                return Error("Invalid Payload");
            if (string.IsNullOrWhiteSpace(contactContract.Name))
            {
                return Error("Invalid partner contact Name");
            }
            _logger.LogInformation("Adding Partner");

            contactContract.Id = 0;
            contactContract.PartnerId = partnerId;

            var command = new AddOrUpdatePartnerContactCommand
            {
                PartnerContact = contactContract,
                UserId = GetUserIdFromClaim()
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // PUT: api/v1/Partners/5/Contacts
        [HttpPut]
        public async Task<IActionResult> UpdatePartnerContactAsync(int partnerId, [FromBody] PartnerContactContract contactContract)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            if (contactContract == null)
                return Error("Invalid Payload");
            if (string.IsNullOrWhiteSpace(contactContract.Name))
            {
                return Error("Invalid partner contact Name");
            }
            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Updating PartnerContact: {contactContract.Id} for Partner: {partnerId}, Requested By: {userId}");

            var command = new AddOrUpdatePartnerContactCommand
            {
                PartnerContact = contactContract,
                UserId = userId
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // DELETE: api/v1/Partners/5/Contacts/9
        [HttpDelete("{partnerContactId}")]
        public async Task<IActionResult> DeletePartnerContactAsync(int partnerId, int partnerContactId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner Id");
            if (partnerContactId < 1)
                return Error("Invalid Contact Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Deleting PartnerContact: {partnerContactId} for Partner: {partnerId}, Requested By: {userId}");

            var command = new DeletePartnerContactCommand
            {
                Id = partnerContactId,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }
    }
}
