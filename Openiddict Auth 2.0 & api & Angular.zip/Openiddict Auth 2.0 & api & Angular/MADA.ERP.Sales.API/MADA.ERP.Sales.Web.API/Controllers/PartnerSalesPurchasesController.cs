﻿namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;

    [Route("api/v1/Partners/{partnerId}/SalesPurchases")]
    [ApiController]
    public class PartnerSalesPurchasesController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<PartnerSalesPurchasesController> _logger;

        public PartnerSalesPurchasesController(IMessages messages, ILogger<PartnerSalesPurchasesController> logger)
        {
            _messages = messages ?? throw new ArgumentNullException(nameof(messages));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        // PUT: api/v1/Partners/5/SalesPurchases
        [HttpPut]
        public async Task<IActionResult> UpdatePartnerSalesPurchasesAsync(int partnerId, [FromBody] PartnerSalesPurchasesContract SalesPurchasesContract)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            if (SalesPurchasesContract == null)
                return Error("Invalid Payload");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Updating PartnerSalesPurchases for Partner: {partnerId}, Requested By: {userId}");

            var command = new UpdatePartnerSalesPurchasesCommand
            {
                PartnerSalesPurchases = SalesPurchasesContract,
                UserId = userId,
                PartnerId = partnerId
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // GET: api/v1/Partners/5/SalesPurchases
        [HttpGet]
        public async Task<IActionResult> GetPartnerContactsAsync(int partnerId)
        {
            if (partnerId < 1)
                return Error("Invalid Partner ID");

            var query = new GetPartnerSalesPurchasesQuery
            { PartnerId = partnerId };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }
    }
}