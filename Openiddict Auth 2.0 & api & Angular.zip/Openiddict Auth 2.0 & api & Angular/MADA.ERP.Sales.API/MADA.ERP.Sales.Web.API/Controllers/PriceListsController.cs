﻿
namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Linq;

    [Route("api/v1/[controller]")]
    [ApiController]
    public class PriceListsController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<PriceListsController> _logger;
        public PriceListsController(IMessages messages, ILogger<PriceListsController> logger)
        {
            _logger = logger;
            _messages = messages;
        }

        // GET: api/v1/PriceLists
        [HttpGet]
        public async Task<IActionResult> GetPriceListsAsync([FromQuery] SearchContract searchContract)
        {
            if (searchContract == null)
                return Error("Invalid Input");
            else if (searchContract.PageNumber < 1)
                return Error("Invalid Page Number");
            else if (searchContract.PageSize < 1)
                return Error("Invalid Page Size");

            _logger.LogInformation("GetPriceListsAsync Called.");

            var query = new GetPriceListsQuery
            {
                SearchContract = searchContract
            };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        // GET: api/v1/PriceLists/5
        [HttpGet("{priceListId}")]
        public async Task<IActionResult> GetPriceListByIdAsync(int priceListId)
        {
            if (priceListId < 1)
                return Error("Invalid price list Id");

            _logger.LogInformation("GetPriceListAsync Called.");

            var query = new GetPriceListQuery
            {
                PriceListId = priceListId
            };

            var priceList = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(priceList);
        }

        // POST: api/v1/PriceLists
        [HttpPost]
        public async Task<IActionResult> AddPriceListAsync([FromBody] PriceListContract priceList)
        {
            if (priceList == null)
                return Error("Invalid Payload");
            if (string.IsNullOrWhiteSpace(priceList.Name))
            {
                return Error("Invalid price list Name");
            }

            _logger.LogInformation("Adding PriceList");

            priceList.Id = 0;
            var command = new AddOrUpdatePriceListCommand
            {
                PriceList = priceList,
                UserId = GetUserIdFromClaim()
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // PUT: api/v1/PriceLists
        [HttpPut]
        public async Task<IActionResult> UpdatePriceListAsync([FromBody] PriceListContract priceList)
        {
            if (priceList == null)
                return Error("Invalid Payload");
            if (string.IsNullOrWhiteSpace(priceList.Name))
            {
                return Error("Invalid price list Name");
            }

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Updating PriceList: {priceList.Id}, Requested By: {userID}");

            var command = new AddOrUpdatePriceListCommand
            {
                PriceList = priceList,
                UserId = userID
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // DELETE: api/v1/PriceLists/5
        [HttpDelete("{priceListId}")]
        public async Task<IActionResult> DeletePriceListAsync(int priceListId)
        {
            if (priceListId < 1)
                return Error("Invalid price list Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Deleting PriceList : {priceListId}, Requested By: {userId}");

            var command = new DeletePriceListCommand
            {
                Id = priceListId,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPost("deleteByIds")]
        public async Task<IActionResult> DeletePriceListsAsync([FromBody] List<int> idsList)
        {
            if (idsList == null)
            {
                return Error("Invalid Payload");
            }
            if (!idsList.Any())
            {
                return Error("Empty PriceList Ids List");
            }
            var userId = GetUserIdFromClaim();
            _logger.LogInformation($"Deleting PriceLists: {string.Join(",", idsList)}, Requested By:{userId}");

            var command = new DeletePriceListsByIdsCommand
            {
                Ids = idsList,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }
    }
}