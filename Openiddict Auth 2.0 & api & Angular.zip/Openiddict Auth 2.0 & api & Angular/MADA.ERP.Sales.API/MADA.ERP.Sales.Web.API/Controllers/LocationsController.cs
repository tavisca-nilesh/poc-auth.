﻿
namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Linq;

    [Route("api/v1/[controller]")]

    [ApiController]
    public class LocationsController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<LocationsController> _logger;
        public LocationsController(IMessages messages, ILogger<LocationsController> logger)
        {
            _logger = logger;
            _messages = messages;
        }

        // GET: api/v1/Locations
        [HttpGet]
        public async Task<IActionResult> GetLocationsAsync([FromQuery] SearchContract searchContract)
        {
            if (searchContract == null)
                return Error("Invalid Input");
            else if (searchContract.PageNumber < 1)
                return Error("Invalid Page Number");
            else if (searchContract.PageSize < 1)
                return Error("Invalid Page Size");

            _logger.LogInformation("GetLocationsAsync Called.");

            var query = new GetLocationListQuery
            {
                SearchContract = searchContract
            };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        // GET: api/v1/Locations/5
        [HttpGet("{locationId}")]
        public async Task<IActionResult> GetLocationByIdAsync(int locationId)
        {
            if (locationId < 1)
                return Error("Invalid LocationId");

            _logger.LogInformation("GetLocationByIdAsync called.");

            var query = new GetLocationQuery
            {
                LocationId = locationId
            };

            var location = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(location);
        }

        // POST: api/v1/Locations
        [HttpPost]
        public async Task<IActionResult> AddLocationAsync([FromBody] LocationContract location)
        {
            if (location == null)
                return Error("Invalid Payload");

            _logger.LogInformation("Adding location");

            location.Id = 0;
            var command = new AddOrUpdateLocationCommand
            {
                Location = location,
                UserId = GetUserIdFromClaim()
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // PUT: api/v1/Locations
        [HttpPut]
        public async Task<IActionResult> UpdateLocationAsync([FromBody] LocationContract location)
        {
            if (location == null)
                return Error("Invalid Payload");

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Updating location: {location.Id}, Requested By: {userID}");

            var command = new AddOrUpdateLocationCommand
            {
                Location = location,
                UserId = userID
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // DELETE: api/v1/Locations/5
        [HttpDelete("{locationId}")]
        public async Task<IActionResult> DeleteLocationAsync(int locationId)
        {
            if (locationId < 1)
                return Error("Invalid location Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Deleting location : {locationId}, Requested By: {userId}");

            var command = new DeleteLocationCommand
            {
                Id = locationId,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPost("deleteByIds")]
        public async Task<IActionResult> DeleteLocationsAsync([FromBody] List<int> idsList)
        {
            if (idsList == null)
            {
                return Error("Invalid Payload");
            }
            if (!idsList.Any())
            {
                return Error("Empty Location Ids List");
            }
            var userId = GetUserIdFromClaim();
            _logger.LogInformation($"Deleting Locations: {string.Join(",", idsList)}, Requested By:{userId}");

            var command = new DeleteLocationsByIdsCommand
            {
                Ids = idsList,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }
    }
}