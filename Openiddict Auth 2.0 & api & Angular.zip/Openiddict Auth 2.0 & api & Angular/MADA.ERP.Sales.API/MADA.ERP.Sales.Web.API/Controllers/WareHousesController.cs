﻿
namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Linq;

    [Route("api/v1/[controller]")]

    [ApiController]
    public class WareHousesController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<WareHousesController> _logger;
        public WareHousesController(IMessages messages, ILogger<WareHousesController> logger)
        {
            _logger = logger;
            _messages = messages;
        }

        // GET: api/v1/WareHouses
        [HttpGet]
        public async Task<IActionResult> GetWareHousesAsync([FromQuery] SearchContract searchContract)
        {
            if (searchContract == null)
                return Error("Invalid Input");
            else if (searchContract.PageNumber < 1)
                return Error("Invalid Page Number");
            else if (searchContract.PageSize < 1)
                return Error("Invalid Page Size");

            _logger.LogInformation("GetWareHousesAsync Called.");

            var query = new GetWareHouseListQuery
            {
                SearchContract = searchContract
            };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        // GET: api/v1/WareHouses/5
        [HttpGet("{wareHouseId}")]
        public async Task<IActionResult> GetWareHouseAsync(int wareHouseId)
        {
            if (wareHouseId < 1)
                return Error("Invalid WareHouse Id");

            _logger.LogInformation("GetWareHouseAsync Called.");

            var query = new GetWareHouseQuery
            {
                WareHouseId = wareHouseId
            };

            var wareHouse = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(wareHouse);
        }

        // POST: api/v1/WareHouses
        [HttpPost]
        public async Task<IActionResult> AddWareHouseAsync([FromBody] WareHouseContract wareHouse)
        {
            if (wareHouse == null)
                return Error("Invalid Payload");

            _logger.LogInformation("Adding WareHouse");

            wareHouse.Id = 0;
            var command = new AddOrUpdateWareHouseCommand
            {
                WareHouse = wareHouse,
                UserId = GetUserIdFromClaim()
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // PUT: api/v1/WareHouses
        [HttpPut]
        public async Task<IActionResult> UpdatePartnerAsync([FromBody] WareHouseContract wareHouse)
        {
            if (wareHouse == null)
                return Error("Invalid Payload");

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Updating WareHouse: {wareHouse.Id}, Requested By: {userID}");

            var command = new AddOrUpdateWareHouseCommand
            {
                WareHouse = wareHouse,
                UserId = userID
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // DELETE: api/v1/WareHouses/5
        [HttpDelete("{wareHouseId}")]
        public async Task<IActionResult> DeleteWareHouseAsync(int wareHouseId)
        {
            if (wareHouseId < 1)
                return Error("Invalid WareHouse Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Deleting WareHouse : {wareHouseId}, Requested By: {userId}");

            var command = new DeleteWareHouseCommand
            {
                Id = wareHouseId,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPost("deleteByIds")]
        public async Task<IActionResult> DeleteWareHousesAsync([FromBody] List<int> idsList)
        {
            if (idsList == null)
            {
                return Error("Invalid Payload");
            }
            if (!idsList.Any())
            {
                return Error("Empty WareHouse Ids List");
            }
            var userId = GetUserIdFromClaim();
            _logger.LogInformation($"Deleting WareHouses: {string.Join(",", idsList)}, Requested By:{userId}");

            var command = new DeleteWarehousesByIdsCommand
            {
                Ids = idsList,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }
    }
}