﻿
namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;
    using MADA.ERP.Sales.Common;
    using System.Collections.Generic;

    [Route("api/v1/[controller]")]
    [ApiController]
    public class SalesOrdersController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<SalesOrdersController> _logger;
        public SalesOrdersController(IMessages messages, ILogger<SalesOrdersController> logger)
        {
            _logger = logger;
            _messages = messages;
        }

        // GET: api/v1/SalesOrders
        [HttpGet]
        public async Task<IActionResult> GetSalesOrdersAsync([FromQuery] SalesOrderSearchContract searchContract)
        {
            if (searchContract == null)
                return Error("Invalid Input");
            else if (searchContract.PageNumber < 1)
                return Error("Invalid Page Number");
            else if (searchContract.PageSize < 1)
                return Error("Invalid Page Size");

            _logger.LogInformation("GetSalesOrdersAsync Called.");

            var query = new GetSalesOrdersQuery
            {
                SearchContract = searchContract
            };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        // GET: api/v1/SalesOrders/5
        [HttpGet("{salesOrderId}")]
        public async Task<IActionResult> GetSalesOrderById(int salesOrderId)
        {
            if (salesOrderId < 1)
                return Error("Invalid SalesOrder Id");

            _logger.LogInformation("GetSalesOrderById Called.");

            var query = new GetSalesOrderQuery
            {
                SalesOrderId = salesOrderId
            };

            var SalesOrder = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(SalesOrder);
        }

        // POST: api/v1/SalesOrders
        [HttpPost]
        public async Task<IActionResult> AddSalesOrderAsync([FromBody] SalesOrderContract salesOrder)
        {
            if (salesOrder == null)
                return Error("Invalid Payload");

            _logger.LogInformation("Adding SalesOrder");

            salesOrder.Id = 0;
            var command = new AddOrUpdateSalesOrderCommand
            {
                SalesOrder = salesOrder,
                UserId = GetUserIdFromClaim()
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // PUT: api/v1/SalesOrders
        [HttpPut]
        public async Task<IActionResult> UpdateSalesOrderAsync([FromBody] SalesOrderContract salesOrder)
        {
            if (salesOrder == null)
                return Error("Invalid Payload");

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Updating SalesOrder: {salesOrder.Id}, Requested By: {userID}");

            var command = new AddOrUpdateSalesOrderCommand
            {
                SalesOrder = salesOrder,
                UserId = userID
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // DELETE: api/v1/SalesOrders/5
        [HttpDelete("{salesOrderId}")]
        public async Task<IActionResult> DeleteSalesOrderAsync(int salesOrderId)
        {
            if (salesOrderId < 1)
                return Error("Invalid SalesOrder Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Deleting SalesOrder: {salesOrderId}, Requested By: {userId}");

            var command = new DeleteSalesOrderCommand
            {
                Id = salesOrderId,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPost("{salesOrderId}/Status")]
        public async Task<IActionResult> UpdateSalesOrderStatus(int salesOrderId, SalesOrderStatus  salesOrderStatus)
        {
            if (salesOrderId < 1)
                return Error("Invalid SalesOrder Id");

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Updating Notes for SalesOrder: {salesOrderId}, Requested By: {userID}");

            var command = new UpdateSalesOrderStatusCommand
            {
                Id = salesOrderId,
                Status = salesOrderStatus,
                UserId = userID
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // GET: api/v1/SalesOrders
        [HttpGet("UnitPrice")]
        public async Task<IActionResult> GetUnitPriceAsync([FromQuery] UnitPriceContract unitPriceContract)
        {
            if (unitPriceContract == null)
                return Error("Invalid Input");
            else if (unitPriceContract.PriceListId < 1)
                return Error("Invalid Price List Id");
            else if (unitPriceContract.ProductId < 1)
                return Error("Invalid Product Id");

            _logger.LogInformation("GetUnitPriceAsync Called.");

            var query = new GetUnitPriceQuery
            {
                UnitPriceContract = unitPriceContract
            };

            var result = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPost("deleteByIds")]
        public async Task<IActionResult> DeleteSalesOrdersAsync([FromBody] List<int> idsList)
        {
            if (idsList == null)
            {
                return Error("Invalid Payload");
            }
            if (!idsList.Any())
            {
                return Error("Empty SalesOrder Ids List");
            }
            var userId = GetUserIdFromClaim();
            _logger.LogInformation($"Deleting SalesOrders: {string.Join(",", idsList)}, Requested By:{userId}");

            var command = new DeleteSalesOrdersByIdsCommand
            {
                Ids = idsList,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }
    }
}