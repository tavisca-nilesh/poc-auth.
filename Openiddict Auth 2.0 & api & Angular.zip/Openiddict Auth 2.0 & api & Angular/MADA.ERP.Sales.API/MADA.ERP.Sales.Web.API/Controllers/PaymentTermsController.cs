﻿
namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;
    using System.Collections.Generic;
    using System.Linq;

    [Route("api/v1/[controller]")]

    [ApiController]
    public class PaymentTermsController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<PaymentTermsController> _logger;
        public PaymentTermsController(IMessages messages, ILogger<PaymentTermsController> logger)
        {
            _logger = logger;
            _messages = messages;
        }

        // GET: api/v1/PaymentTerms
        [HttpGet]
        public async Task<IActionResult> GetPaymentTermsAsync([FromQuery] SearchContract searchContract)
        {
            if (searchContract == null)
                return Error("Invalid Input");
            else if (searchContract.PageNumber < 1)
                return Error("Invalid Page Number");
            else if (searchContract.PageSize < 1)
                return Error("Invalid Page Size");

            _logger.LogInformation("GetPaymentTermsAsync Called.");

            var query = new GetPaymentTermsQuery
            {
                SearchContract = searchContract
            };

            var list = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(list);
        }

        //GET api/v1/PaymentTerms/5
        [HttpGet("{paymentTermId}")]
        public async Task<IActionResult> GetPaymentTermAsync(int paymentTermId)
        {
            if (paymentTermId < 1)
                return Error("Invalid payment term Id");

            _logger.LogInformation("GetPaymentTermAsync Called.");

            var query = new GetPaymentTermQuery
            {
                PaymentTermId = paymentTermId
            };

            var paymentTerm = await _messages.Dispatch(query).ConfigureAwait(false);
            return Ok(paymentTerm);
        }

        // POST: api/v1/PaymentTerms
        [HttpPost]
        public async Task<IActionResult> AddPaymentTermAsync([FromBody] PaymentTermContract paymentTerm)
        {
            if (paymentTerm == null)
                return Error("Invalid Payload");

            _logger.LogInformation("Adding Payment term");

            paymentTerm.Id = 0;
            var command = new AddOrUpdatePaymentTermCommand
            {
                PaymentTerm = paymentTerm,
                UserId = GetUserIdFromClaim()
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // PUT: api/v1/PaymentTerms
        [HttpPut]
        public async Task<IActionResult> UpdatePartnerAsync([FromBody] PaymentTermContract paymentTerm)
        {
            if (paymentTerm == null)
                return Error("Invalid Payload");

            var userID = GetUserIdFromClaim();

            _logger.LogInformation($"Updating Payment term: {paymentTerm.Id}, Requested By: {userID}");

            var command = new AddOrUpdatePaymentTermCommand
            {
                PaymentTerm = paymentTerm,
                UserId = userID
            };

            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        // DELETE: api/v1/PaymentTerms/5
        [HttpDelete("{paymentTermId}")]
        public async Task<IActionResult> DeletePaymentTermAsync(int paymentTermId)
        {
            if (paymentTermId < 1)
                return Error("Invalid payment term Id");

            var userId = GetUserIdFromClaim();

            _logger.LogInformation($"Deleting payment term : {paymentTermId}, Requested By: {userId}");

            var command = new DeletePaymentTermCommand
            {
                Id = paymentTermId,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }

        [HttpPost("deleteByIds")]
        public async Task<IActionResult> DeletePaymentTermsAsync([FromBody] List<int> idsList)
        {
            if (idsList == null)
            {
                return Error("Invalid Payload");
            }
            if (!idsList.Any())
            {
                return Error("Empty PaymentTerm Ids List");
            }
            var userId = GetUserIdFromClaim();
            _logger.LogInformation($"Deleting PaymentTerms: {string.Join(",", idsList)}, Requested By:{userId}");

            var command = new DeletePaymentTermsByIdsCommand
            {
                Ids = idsList,
                UserId = userId
            };
            var result = await _messages.Dispatch(command).ConfigureAwait(false);
            return Ok(result);
        }
    }
}