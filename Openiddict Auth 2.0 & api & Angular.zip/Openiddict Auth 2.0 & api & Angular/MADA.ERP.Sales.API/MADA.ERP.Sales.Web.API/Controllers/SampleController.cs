
namespace MADA.ERP.Sales.Web.Api.Controllers
{
    using MADA.ERP.Sales.Engine.Commands;
    using MADA.ERP.Sales.Engine.Queries;
    using MADA.ERP.Sales.Engine.Utils;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Threading.Tasks;

    [ApiController]
    [Route("api/v1.0/sample")]
    public sealed class SampleController : BaseController
    {
        private readonly IMessages _messages;
        private readonly ILogger<SampleController> _logger;
        public SampleController(IMessages messages, ILogger<SampleController> logger)
        {
            _logger = logger;
            _messages = messages;
        }

        [HttpGet, Route("")]
        public async Task<IActionResult> GetSamplesAsync()
        {
            var userId = GetUserIdFromClaim();
            _logger.LogInformation("GetSampleAsync Called.");

            var list = await _messages.Dispatch(new GetSampleListQuery()).ConfigureAwait(false);
            return Ok(list);
        }

        [HttpPost, Route("")]
        public async Task<IActionResult> AddSampleAsync([FromBody] string name)
        {

            _logger.LogInformation("AddSampleAsync Called.");
            if (name == "string")
            {
                return Error("Invalid Input");
            }

            var result = await _messages.Dispatch(new AddSampleCommand(name)).ConfigureAwait(false);
            return Ok(result);
        }
    }
}
