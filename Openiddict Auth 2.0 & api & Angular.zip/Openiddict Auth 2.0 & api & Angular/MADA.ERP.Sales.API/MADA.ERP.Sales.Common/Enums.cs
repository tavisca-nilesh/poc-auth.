﻿namespace MADA.ERP.Sales.Common
{
    public enum PartnerType
    {
        Undefined = 0,
        Individual = 1,
        Company = 2
    }

    public enum ContactType
    {
        Undefined = 0,
        ShipmentAddress = 1,
        InvoiceAddress = 2,
        Contact = 3
    }

    public enum PriceListType
    {
        Customer = 1,
        Vendor = 2,
        Location = 3
    }

    public enum SalesOrderStatus
    {
        Undefined = 0,
        Quotation = 1,
        QuotationSent = 2,
        SalesOrder = 3,
        Locked = 4,
        DirectSalesOrder = 5,
        Cancelled = 6
    }

    public enum PartnerSearchType
    {
        Customer = 1,
        Employee = 2,
        Vendor = 3,
        All = 4
    }

    public enum LocationType
    {
        InteralLocation = 1,
        CustomerLocation = 2,
        VendorLocation = 3,
        InventoryLocation = 4,
        Procurement = 5,
        Prodution = 6,
        TransitLocation = 7
    }

    public enum PartnerPageType
    {
        Customer = 1,
        Vendor = 2
    }
}
