﻿namespace MADA.ERP.Sales.Common
{
    public static class StoredProcedureConstants
    {
        public static string GetPartnerList = "spSales_GetPartners";
        public static string GetPartnerById = "spSales_GetPartnerById";
        public static string UpsertPartner = "spSales_UpsertPartner";
        public static string DeletePartner = "spSales_DeletePartner";
        public static string GetPartnerContacts = "spSales_GetPartnerContacts";
        public static string GetPartnerContactById = "spSales_GetPartnerContactById";
        public static string UpsertPartnerContact = "spSales_UpsertPartnerContact";
        public static string DeletePartnerContact = "spSales_DeletePartnerContact";
        public static string UpdatePartnerNotes = "spSales_UpdatePartnerNotes";
        public static string GetPaymentTerms = "spSales_GetPaymentTerms";
        public static string GetPaymentTermById = "spSales_GetPaymentTermById";
        public static string UpsertPaymentTerm = "spSales_UpsertPaymentTerms";
        public static string DeletePaymentTerm = "spSales_DeletePaymentTerms";
        public static string UpsertPriceList = "spSales_UpsertPriceList";
        public static string GetPriceListById = "spSales_GetPriceListById";
        public static string DeletePriceList = "spSales_DeletePriceList";
        public static string GetWareHouses = "spSales_GetWareHouses";
        public static string GetWareHouseById = "spSales_GetWareHouseById";
        public static string UpsertWareHouse = "spSales_UpsertWareHouse";
        public static string DeleteWareHouse = "spSales_DeleteWareHouse";
        public static string GetLocations = "spSales_GetLocations";
        public static string GetLocationById = "spSales_GetLocationById";
        public static string UpsertLocation = "spSales_UpsertLocation";
        public static string DeleteLocation = "spSales_DeleteLocation";
        public static string GetPriceListDetails = "spSales_GetPriceListDetails";
        public static string UpsertPriceListDetail = "spSales_UpsertPriceListDetail";
        public static string DeletePriceListDetail = "spSales_DeletePriceListDetail";
        public static string GetPartnerBanks = "spSales_GetPartnerBanks";
        public static string GetPartnerBankById = "spSales_GetPartnerBankById";
        public static string UpsertPartnerBank = "spSales_UpsertPartnerBank";
        public static string DeletePartnerBank = "spSales_DeletePartnerBank";
        public static string UpsertPartnerIcon = "spSales_UpsertPartnerIcon";
        public static string UpsertPartnerAccount = "spSales_UpsertPartnerAccount";
        public static string DeletePartnerAccount = "spSales_DeletePartnerAccount";
        public static string GetPartnerAccountById = "spSales_GetPartnerAccountById";
        public static string GetPartnerAccounts = "spSales_GetPartnerAccounts";
        public static string UpdatePartnerSalesPurchases = "spSales_UpdatePartnerSalesPurchases";
        public static string GetPartnerSalesPurchases = "spSales_GetPartnerSalesPurchases";
        public static string GetPriceLists = "spSales_GetPriceLists";
        public static string GetBanks = "spSales_GetBanks";
        public static string GetBankById = "spSales_GetBankById";
        public static string UpsertBank = "spSales_UpsertBank";
        public static string DeleteBank = "spSales_DeleteBank";
        public static string GetPartnerNotes = "spSales_GetPartnerNotes";
        public static string UpdatePartnerStatus = "spSales_UpdatePartnerStatus";
        public static string GetPartnerListByType = "spSales_GetPartnersByType";
        public static string GetSalesOrders = "spSales_GetSalesOrders";
        public static string GetSalesOrderById = "spSales_GetSalesOrderById";
        public static string UpsertSalesOrder = "spSales_UpsertSalesOrder";
        public static string DeleteSalesOrder = "spSales_DeleteSalesOrder";
        public static string UpdateSalesOrderStatus = "spSales_UpdateSalesOrderStatus";
        public static string UpdatePartnerAssignation = "spSales_UpdatePartnerAssignation";
        public static string GetPartnerAssignation = "spSales_GetPartnerAssignation";
        public static string GetUnitPrice = "spSales_GetUnitPrice";
        public static string DeleteBanksByIds = "spSales_DeleteBanksByIds";
        public static string DeleteLocationsByIds = "spSales_DeleteLocationsByIds";
        public static string DeleteSalesOrdersByIds = "spSales_DeleteSalesOrdersByIds";
        public static string DeletePaymentTermsByIds = "spSales_DeletePaymentTermsByIds";
        public static string DeletePriceListsByIds = "spSales_DeletePriceListsByIds";
        public static string DeleteWarehousesByIds = "spSales_DeleteWarehousesByIds";
        public static string DeletePartnersByIds = "spSales_DeletePartnersByIds";
        
    }
}
