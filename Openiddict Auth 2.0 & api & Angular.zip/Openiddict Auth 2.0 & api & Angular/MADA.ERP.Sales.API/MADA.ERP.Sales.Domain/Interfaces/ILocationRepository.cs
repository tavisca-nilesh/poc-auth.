﻿
namespace MADA.ERP.Sales.Domain.Interfaces
{
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface ILocationRepository
    {
        Task<LocationListDomain> GetLocationListAsync(SearchContract searchContract);
        Task<LocationDomain> GetLocationByIdAsync(int locationId);
        Task<int> AddOrUpdateLocationAsync(LocationContract location, int userId);
        Task<bool> DeleteLocationAsync(int locationId, int userId);
        Task<SuccessFailureDomain> DeleteLocationsByIdsAsync(List<int> ids, int userId);
    }
}
