namespace MADA.ERP.Sales.Domain.Interfaces
{
    using System.Data;
    public interface IConnectionFactory
    {
        IDbConnection GetDbConnection();
    }
}
