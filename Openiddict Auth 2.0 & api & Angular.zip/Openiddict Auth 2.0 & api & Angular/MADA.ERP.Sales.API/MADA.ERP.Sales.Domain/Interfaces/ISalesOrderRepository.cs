﻿
namespace MADA.ERP.Sales.Domain.Interfaces
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    public interface ISalesOrderRepository
    {
        Task<SalesOrderListDomain> GetSalesOrderListAsync(SalesOrderSearchContract searchContract);
        Task<SalesOrderDomain> GetSalesOrderByIdAsync(int salesOrderId);
        Task<int> AddOrUpdateSalesOrderAsync(SalesOrderContract salesOrder, int userId);
        Task<bool> DeleteSalesOrderAsync(int salesOrderId, int userId);
        Task<int> UpdateSalesOrderStatus(int salesOrderId,SalesOrderStatus salesOrderStatus, int userId);
        Task<UnitPriceDomain> GetUnitPrice(UnitPriceContract unitPriceContract);
        Task<SuccessFailureDomain> DeleteSalesOrdersByIdsAsync(List<int> ids, int userId);
    }
}
