﻿
namespace MADA.ERP.Sales.Domain.Interfaces
{
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    public interface IWareHouseRepository
    {
        Task<WareHouseListDomain> GetWareHouseListAsync(SearchContract searchContract);
        Task<WareHouseDomain> GetWareHouseByIdAsync(int wareHouseId);
        Task<int> AddOrUpdateWareHouseAsync(WareHouseContract wareHouse, int userId);
        Task<bool> DeleteWareHouseAsync(int wareHouseId, int userId);
        Task<SuccessFailureDomain> DeleteWarehousesByIdsAsync(List<int> ids, int userId);
    }
}
