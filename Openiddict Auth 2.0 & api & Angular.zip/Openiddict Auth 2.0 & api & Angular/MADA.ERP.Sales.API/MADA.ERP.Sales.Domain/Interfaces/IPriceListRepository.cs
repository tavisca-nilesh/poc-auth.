﻿
namespace MADA.ERP.Sales.Domain.Interfaces
{
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IPriceListRepository
    {
        Task<PriceListDomain> GetPriceListByIdAsync(int PartnerPriceListId);
        Task<int> AddOrUpdatePriceListAsync(PriceListContract priceList, int userId);
        Task<bool> DeletePriceListAsync(int priceListId, int userId);
        Task<PriceListDomainList> GetPriceListsAsync(SearchContract searchContract);
        Task<SuccessFailureDomain> DeletePriceListsByIdsAsync(List<int> ids, int userId);
    }
}
