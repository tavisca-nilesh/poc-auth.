﻿namespace MADA.ERP.Sales.Domain.Interfaces
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;

    public interface IPartnerBankRepository
    {
        Task<List<PartnerBankDomain>> GetPartnerBanksAsync(int partnerId);
        Task<PartnerBankDomain> GetPartnerBankByIdAsync(int partnerId, int bankId);
        Task<int> AddOrUpdatePartnerBankAsync(PartnerBankContract partnerBank, int userId);
        Task<bool> DeletePartnerBankAsync(int partnerBankId, int userId);
    }
}
