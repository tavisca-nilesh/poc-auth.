
namespace MADA.ERP.Sales.Domain.Interfaces
{
    using MADA.ERP.Sales.Contract.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IDataRepository
    {
        Task<List<SampleContract>> GetSampleListAsync();

        bool TryConnect(out string message);

    }
}
