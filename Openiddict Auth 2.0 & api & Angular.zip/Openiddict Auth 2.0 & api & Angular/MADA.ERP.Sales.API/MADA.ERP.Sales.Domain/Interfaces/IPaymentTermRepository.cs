﻿
namespace MADA.ERP.Sales.Domain.Interfaces
{
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IPaymentTermRepository
    {
        Task<PaymentTermListDomain> GetPaymentTermListAsync(SearchContract searchContract);
        Task<PaymentTermDomain> GetPaymentTermByIdAsync(int paymentTermId);
        Task<int> AddOrUpdatePaymentTermAsync(PaymentTermContract paymentTerm, int userId);
        Task<bool> DeletePaymentTermAsync(int paymentTermId, int userId);
        Task<SuccessFailureDomain> DeletePaymentTermsByIdsAsync(List<int> ids, int userId);
    }
}
