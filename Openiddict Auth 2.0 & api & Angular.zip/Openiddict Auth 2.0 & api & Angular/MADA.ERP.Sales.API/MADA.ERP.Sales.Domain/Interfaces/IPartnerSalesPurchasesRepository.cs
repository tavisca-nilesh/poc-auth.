﻿namespace MADA.ERP.Sales.Domain.Interfaces
{
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;

    public interface IPartnerSalesPurchasesRepository
    {
        Task<int> UpdatePartnerSalesPurchasesAsync(PartnerSalesPurchasesContract partnerSalesPurchases, int purchaseId, int userId);
        Task<PartnerSalesPurchasesDomain> GetPartnerSalesPurchasesAsync(int partnerId);
    }
}