
namespace MADA.ERP.Sales.Domain.Interfaces
{
	public interface INudgeEngine
	{
		bool Nudge(out string message);
	}
}
