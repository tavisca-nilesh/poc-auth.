﻿namespace MADA.ERP.Sales.Domain.Interfaces
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;

    public interface IPartnerContactRepository
    {
        Task<List<PartnerContactDomain>> GetPartnerContactsAsync(int partnerId);
        Task<PartnerContactDomain> GetPartnerContactByIdAsync(int partnerId, int partnerContactId);
        Task<int> AddOrUpdatePartnerContactAsync(PartnerContactContract partnerContact, int userId);
        Task<bool> DeletePartnerContactAsync(int partnerContactId, int userId);
    }
}
