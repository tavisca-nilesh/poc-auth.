﻿
namespace MADA.ERP.Sales.Domain.Interfaces
{
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    public interface IBankRepository
    {
        Task<BankListDomain> GetBankListAsync(SearchContract searchContract);
        Task<BankDomain> GetBankByIdAsync(int bankId);
        Task<int> AddOrUpdateBankAsync(BankContract bank, int userId);
        Task<bool> DeleteBankAsync(int bankId, int userId);
        Task<SuccessFailureDomain> DeleteBanksByIdsAsync(List<int> ids, int userId);
    }
}
