﻿namespace MADA.ERP.Sales.Domain.Interfaces
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;

    public interface IPartnerAccountRepository
    {
        Task<List<PartnerAccountDomain>> GetPartnerAccountsAsync(int partnerId);
        Task<PartnerAccountDomain> GetPartnerAccountByIdAsync(int partnerId, int partnerAccountId);
        Task<int> AddOrUpdatePartnerAccountAsync(PartnerAccountContract partnerAccount, int userId);
        Task<bool> DeletePartnerAccountAsync(int partnerAccountId, int userId);
    }
}
