﻿namespace MADA.ERP.Sales.Domain.Interfaces
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using MADA.ERP.Sales.Domain.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IPartnerRepository
    {
        Task<PartnerListDomain> GetPartnerListAsync(PartnerSearchContract searchContract);
        Task<int> AddOrUpdatePartnerAsync(PartnerContract partner, int userId);
        Task<bool> DeletePartnerAsync(int partnerId, int userId);
        Task<int> UpdatePartnerNoteAsync(int partnerId, string note, int userId);
        Task<PartnerFullDomain> GetPartnerByIdAsync(int partnerId);
        Task<int> AddOrUpdatePartnerIconAsync(PartnerIconContract partnerIcon, int userId);
        Task<PartnerNoteDomain> GetPartnerNoteAsync(int partnerId);
        Task<int> UpdatePartnerStatusAsync(int partnerId, bool status, int userId);
        Task<PartnerListDomain> GetPartnerListByTypeAsync(PartnerSearchType searchByTypeContract, PartnerSearchContract searchContract);
        Task<int> UpdatePartnerAssignationAsync(int partnerId, PartnerAssignationContract partnerAssignation, int userId);
        Task<PartnerAssignationDomain> GetPartnerAssignationAsync(int partnerId);
        Task<SuccessFailureDomain> DeletePartnersByIdsAsync(List<int> ids, int userId);
    }
}
