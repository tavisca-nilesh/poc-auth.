
namespace MADA.ERP.Sales.Domain.Messages
{
    public class SampleMessage
    {
        public string Name { get; set; }
    }
}
