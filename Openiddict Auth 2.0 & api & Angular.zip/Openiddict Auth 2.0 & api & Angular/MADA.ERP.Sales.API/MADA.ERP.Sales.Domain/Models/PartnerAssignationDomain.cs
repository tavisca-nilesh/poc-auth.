﻿
namespace MADA.ERP.Sales.Domain.Models
{
    public class PartnerAssignationDomain
    {
        public int Id { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
    }
}
