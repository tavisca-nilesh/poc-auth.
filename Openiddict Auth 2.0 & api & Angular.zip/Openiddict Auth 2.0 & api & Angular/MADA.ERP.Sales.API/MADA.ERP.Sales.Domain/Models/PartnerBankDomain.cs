﻿namespace MADA.ERP.Sales.Domain.Models
{
    public class PartnerBankDomain : AuditDomain
    {
        public int Id { get; set; }
        public string AccountNumber { get; set; }
        public int PartnerId { get; set; }
        public string PartnerName { get; set; }
        public int BankId { get; set; }
        public string BankName { get; set; }
        public int CurrencyId { get; set; }
        public string CurrencyName { get; set; }
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public bool Active { get; set; }
    }
}
