﻿
using System.Collections.Generic;

namespace MADA.ERP.Sales.Domain.Models
{
    public class BankListDomain {
        public List<BankDomain> Banks { get; set; }
        public PaginationInfo Pagination { get; set; }
    }
    public class BankDomain : AuditDomain
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string SLName { get; set; }
    }
}
