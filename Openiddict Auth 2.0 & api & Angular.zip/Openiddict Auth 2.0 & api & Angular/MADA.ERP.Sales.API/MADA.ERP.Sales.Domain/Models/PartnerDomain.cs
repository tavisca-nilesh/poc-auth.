﻿namespace MADA.ERP.Sales.Domain.Models
{
    using MADA.ERP.Sales.Common;
    using System.Collections.Generic;

    public class PartnerListDomain
    {
        public List<PartnerDomain> Partners { get; set; }
        public PaginationInfo Pagination { get; set; }
    }

    public class PartnerDomain : AuditDomain
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string SLName { get; set; }
        public string DisplayName { get; set; }
        public int? TitleId { get; set; }
        public string Title { get; set; }
        public int? CompanyId { get; set; }
        public string CompanyName { get; set; }
        public int? LangId { get; set; }
        public string LanguageName { get; set; }
        public int? TimezoneId { get; set; }
        public string TimeZoneName { get; set; }
        public string TIN { get; set; }
        public string Website { get; set; }
        public double CreditLimit { get; set; }
        public bool Active { get; set; }
        public bool IsEmployee { get; set; }
        public string JobPosition { get; set; }
        public string Street { get; set; }
        public string Street2 { get; set; }
        public string Zip { get; set; }
        public int? CityId { get; set; }
        public string CityName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Mobile { get; set; }
        public bool IsCompany { get; set; }
        public PartnerType PartnerType { get; set; }
        public byte[] Icon { get; set; }
        public int PriceListId { get; set; }
        public string PriceListName { get; set; }
    }
}
