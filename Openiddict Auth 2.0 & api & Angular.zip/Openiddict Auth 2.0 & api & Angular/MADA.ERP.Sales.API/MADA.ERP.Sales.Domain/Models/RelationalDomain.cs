﻿namespace MADA.ERP.Sales.Domain.Models
{
    public class RelationalDomain
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
