﻿
namespace MADA.ERP.Sales.Domain.Models
{
    using System;
    using System.Collections.Generic;

    public class PaymentTermListDomain
    {
        public List<PaymentTermDomain> PaymentTerms { get; set; }
        public PaginationInfo Pagination { get; set; }
    }

    public class PaymentTermDomain : AuditDomain
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int NoOfDays { get; set; }
    }
}
