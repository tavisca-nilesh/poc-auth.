﻿
namespace MADA.ERP.Sales.Domain.Models
{
    using MADA.ERP.Sales.Common;
    using System;
    using System.Collections.Generic;

    public class LocationListDomain
    {
        public List<LocationDomain> Locations { get; set; }
        public PaginationInfo Pagination { get; set; }
    }

    public class LocationDomain : AuditDomain
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string SLName { get; set; }
        public int ParentWareHouseId { get; set; }
        public string ParentWareHouseName { get; set; }
        public LocationType LocationType { get; set; }
        public bool IsScrap { get; set; }
        public bool IsReturn { get; set; }
        public string Barcode { get; set; }
        public int OwnerId { get; set; }
        public string OwnerName { get; set; }
    }
}
