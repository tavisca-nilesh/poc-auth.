﻿namespace MADA.ERP.Sales.Domain.Models
{
    using System.Collections.Generic;

    public class PartnerFullDomain : PartnerDomain
    {
        public List<RelationalDomain> Banks { get; set; }
        public List<RelationalDomain> Contacts { get; set; }
    }
}
