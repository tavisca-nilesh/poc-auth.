﻿
namespace MADA.ERP.Sales.Domain.Models
{
    using MADA.ERP.Sales.Common;
    using System;
    using System.Collections.Generic;

    public class PriceListDomainList
    {
        public List<PriceListDomain> PriceLists { get; set; }
        public PaginationInfo Pagination { get; set; }
    }
    public class PriceListDomain : AuditDomain
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public PriceListType TypeOfPriceList { get; set; }
        public int? LocationId { get; set; }
        public string LocationName { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool IsPromotional { get; set; }
        public bool IsUpdateTransValue { get; set; }
        public bool IsUpdatePost { get; set; }
        public bool IsPublic { get; set; }
    }
}
