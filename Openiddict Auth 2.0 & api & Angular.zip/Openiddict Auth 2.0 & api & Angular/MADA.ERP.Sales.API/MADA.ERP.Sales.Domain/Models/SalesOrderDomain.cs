﻿
namespace MADA.ERP.Sales.Domain.Models
{
    using MADA.ERP.Sales.Common;
    using MADA.ERP.Sales.Contract.Models;
    using System;
    using System.Collections.Generic;


    public class SalesOrderListDomain
    {
        public List<SalesOrderDomain> SalesOrders { get; set; }
        public PaginationInfo Pagination { get; set; }
    }

    public class SalesOrderDomain : AuditDomain
    {
        public int Id { get; set; }
        public string SalesOrderNumber { get; set; }
        public string CustomerReference { get; set; }
        public SalesOrderStatus Status { get; set; }
        public DateTime? QuotationDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public DateTime? ConfirmationDate { get; set; }
        public int SalesPersonId { get; set; }
        public int PartnerId { get; set; }
        public string PartnerName { get; set; }
        public int InvoiceAddressId { get; set; }
        public string InvoiceAddressName { get; set; }
        public int DeliveryAddressId { get; set; }
        public string DeliveryAddressName { get; set; }
        public int PricelistId { get; set; }
        public string PriceListName { get; set; }
        public int CurrencyId { get; set; }
        public string CurrencyName { get; set; }
        public int NumberOfDigits { get; set; }
        public double ExchangeRate { get; set; }
        public string TermsAndConditions { get; set; }
        public double UnTaxedAmount { get; set; }
        public double Taxes { get; set; }
        public double Total { get; set; }
        public double DiscountAmt { get; set; }
        public int PaymentTermsId { get; set; }
        public string PaymentTermsName { get; set; }
        public int LocationId { get; set; }
        public string LocationName { get; set; }
        public int ShippingPolicyId { get; set; }
        public int VersionId { get; set; }
        public bool IsVersion { get; set; }
        public List<SalesOrderLineDomain> SalesOrderLine { get; set; }
    }
}
