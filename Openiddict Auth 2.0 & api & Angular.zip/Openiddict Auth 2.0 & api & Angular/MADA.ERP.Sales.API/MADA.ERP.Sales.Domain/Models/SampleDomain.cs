
namespace MADA.ERP.Sales.Domain.Models
{
    public class SampleDomain
    {
        public string Name { get; set; }
    }
}
