﻿
namespace MADA.ERP.Sales.Domain.Models
{
    public class PriceListDetailDomain
    {
        public int Id { get; set; }
        public int PriceListId { get; set; }
        public string PriceListName { get; set; }
        public int ProductId { get; set; }
        public int UnitId { get; set; }
        public string UnitName { get; set; }
        public float UnitPrice { get; set; }
        public float SpecialPrice { get; set; }
        public float MinQty { get; set; }

    }
}
