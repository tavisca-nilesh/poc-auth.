﻿
namespace MADA.ERP.Sales.Domain.Models
{
    public class PartnerNoteDomain
    {
        public int Id { get; set; }
        public string Notes { get; set; }
    }
}
