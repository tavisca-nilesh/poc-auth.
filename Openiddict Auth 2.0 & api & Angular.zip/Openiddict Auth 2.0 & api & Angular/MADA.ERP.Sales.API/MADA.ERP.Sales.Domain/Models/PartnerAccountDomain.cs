﻿namespace MADA.ERP.Sales.Domain.Models
{
    public class PartnerAccountDomain : AuditDomain
    {
        public int Id { get; set; }
        public int PartnerId { get; set; }
        public int CustomerTermsId { get; set; }
        public string CustomerTermsName { get; set; }
        public int VendorTermsId { get; set; }
        public string VendorTermsName { get; set; }
        public int DegreeOfTrustId { get; set; }
        public int AccountRecId { get; set; }
        public string AccountRecName { get; set; }
        public int AccountPayId { get; set; }
        public string AccountPayName { get; set; }
        public bool Active { get; set; }
    }
}
