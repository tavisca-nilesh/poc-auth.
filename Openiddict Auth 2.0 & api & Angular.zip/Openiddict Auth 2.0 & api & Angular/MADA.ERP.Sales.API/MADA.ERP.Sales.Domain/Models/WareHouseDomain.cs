﻿
namespace MADA.ERP.Sales.Domain.Models
{
    using System;
    using System.Collections.Generic;

    public class WareHouseListDomain
    {
        public List<WareHouseDomain> WareHouses { get; set; }
        public PaginationInfo Pagination { get; set; }
    }

    public class WareHouseDomain : AuditDomain
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string SLName { get; set; }
    }
}
