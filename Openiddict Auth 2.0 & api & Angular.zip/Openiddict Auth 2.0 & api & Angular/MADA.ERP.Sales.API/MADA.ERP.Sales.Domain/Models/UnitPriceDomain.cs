﻿
namespace MADA.ERP.Sales.Domain.Models
{
    public class UnitPriceDomain
    {
        public double UnitPrice { get; set; }
    }
}
