﻿namespace MADA.ERP.Sales.Domain.Models
{
    public class PartnerSalesPurchasesDomain
    {
        public int PartnerId { get; set; }
        public bool IsCustomer { get; set; }
        public bool IsVendor { get; set; }
        public int? SalesPersonId { get; set; }
        public string InternalRef { get; set; }
        public int PriceListId { get; set; }
        public string PriceListName { get; set; }
        public string Barcode { get; set; }
        public int SupplierCurrencyId { get; set; }
        public bool IsPreferEReceipt { get; set; }
    }
}
