﻿namespace AuthorizationServer.ViewModels
{
    public class LogoutViewModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string? PostLogoutReturnUrl { get; set; }
        public string? PostLogoutRedirectUris { get; set; }
        public string? post_logout_redirect_uri { get; set; }
    }
}